# crown dma

External DMA ESP for the IL2CPP Unity build dumped in this folder.

The project contains:

* **ESP**: 2D boxes, player names, roles, distance, health bars and snaplines,
  drawn with a transparent DirectX 11 / Dear ImGui overlay.
* **Role ESP**: each player is classified as **Police**, **Robber**,
  **Civil** (Citizen / Settler / Hubber), **Prisoner** or **Clan**.  The exact
  classification compares the character's `PlayerRoleDescription*` with the
  game's own role table (`PlayerRoleDescriptions`, read from its static
  fields).  While that table is not available yet, the raw role id string is
  used as a fallback.  The Roles tab has per-role filters, labels and colors.
* **Wallhack**: writes the game's own character-overlay visibility flags and the
  `NicknameSameRoleVisibleThroughWall` role flag, so the built-in name tags are
  drawn through geometry.  The ESP overlay itself is always drawn through
  walls.
* **Menu**: `zintix_menu.cpp` is the only UI of the cheat (Visuals, Roles,
  Miscellaneous, Configuration, SDK).  It also handles config save/load and the
  streamproof toggle.
* **Offset generator**: `tools/gen_offsets.py` reads the Il2CppDumper output in
  this folder (`dump.cs`, `script.json`) and generates
  `src/game/offsets.h`.  Nothing in the cheat hard-codes a field offset by hand
  except the IL2CPP object layout constants in `src/game/memory.h`.

The cheat needs **read and write** access to the game.  Read-only DMA can draw
ESP; the wallhack toggle requires an FPGA that supports memory writes.

## How it finds the world

### Roles

The role system is `Models.References.Battle.PlayerRoleDescription`.  The game
creates one immutable instance per role in the static class
`PlayerRoleDescriptions` and replicates the reference through
`BattleCharacterCommonData::Role`.  The cheat reads the role instance table once
from the static fields (offset generated into `offsets.h`) and compares the
character's role pointer against it, which is exact and needs no string
parsing.  If the table is not initialised yet, the role's id string is matched
against the usual names (`citizen`, `robber`, `cop`, `prisoner`, ...).

Role mapping used by the ESP:

| ESP group | game role |
| --- | --- |
| Police | Cop |
| Robber | Robber |
| Civil | Citizen, Settler, Hubber |
| Prisoner | Prisoner |
| Clan | ClanBattleMember |

The Roles tab toggles each group independently and sets its color.  A player
with the same role as you is drawn green when *Highlight Same Role* is on.

The game is ECS based, so there is no classic `LocalPlayer` static pointer.
The worker resolves the `Il2CppClass*` for `BattleModel` from the metadata-usage
slot in `script.json`, then finds the live `BattleModel` instance with a DMA
memory search (a validated object-header scan done by MemProcFS's search
engine).  From there it follows:

```
Game.Battle.BattleModel
  +0x90  IBattleEntitiesModel  -> BattleEntitiesModel
          +0x60 WorldEntitiesModel -> _battleCharacters Dictionary<int, BattleCharacterModel>
          +0x80 ClientCharacterSlotsModel -> _slotByEntityId (nicknames)
          +0xD0 PlayerEntityModel -> ServerModel (local player)
  +0x358 BattleCameraModel (position / orientation / basis)
  +0x438 OverlayModel (wallhack name tags)
```

The `CinemachineBrain` instance is found in the same memory search when
possible and its `CameraState.Lens.FieldOfView` is used for an exact
world-to-screen projection.  If it is not found, the FOV slider in the menu is
used instead.

Per-frame reads are ordinary `VMMDLL_MemReadEx` calls; the initial heap scan is
the only slow operation.

## Build

1. Download a MemProcFS release for Windows x64 (the release that ships
   `vmm.dll` / `vmm.lib` and the headers).
2. Build with CMake and MSVC:

```bat
cmake -S . -B build -A x64 -DMEMPROCFS_SDK=C:/Tools/MemProcFS
cmake --build build --config Release
```

The ImGui dependency is downloaded by CMake.  If your SDK stores headers in a
different layout, point `MEMPROCFS_SDK` at the folder that directly contains
`vmmdll.h`.

3. Put `vmm.dll` and `leechcore.dll` next to `crown_dma.exe` (CMake copies them
   when it can find them in the SDK folder).

## Run

```bat
crown_dma.exe --process Crown.exe --device fpga
```

Examples:

```bat
:: change the DMA device string
crown_dma.exe --process Crown.exe --device "fpga://algo=2"

:: read from a physical memory dump instead of live DMA
crown_dma.exe --process Crown.exe --device "file://C:\dumps\mem.raw"

:: pass an extra MemProcFS argument
crown_dma.exe --process Crown.exe --device fpga --dma-arg -v
```

`--process` is the actual executable name of the game; the default `Crown.exe`
is only a guess.  Use the name shown in Task Manager, e.g.
`Crown-Win64-Shipping.exe`.

Run the game in **borderless windowed** mode.  The overlay is a topmost
click-through DWM window; exclusive fullscreen will hide it.

Hotkeys:

| key | action |
| --- | --- |
| INS | menu / settings |
| F1 | ESP on/off |
| F2 | wallhack on/off |
| F3 | names |
| F4 | boxes |
| F5 | health bars |
| F6 | distance |
| F7 | snaplines |

The menu key is read from the config (`menu_key`, VK code); the default is
INSERT.  *Configuration → Save Config* writes `crown_dma.cfg` next to the
executable, *Load Config* reads it back (including the wallhack state).
*Miscellaneous → Streamproof* hides the overlay from OBS/screen capture via
`SetWindowDisplayAffinity`.

## DMA not connecting

The console prints the exact MemProcFS / LeechCore error text, and the
*Miscellaneous → DMA* card shows it too.  Press **Reconnect DMA** after fixing
the device; the worker re-runs `VMMDLL_InitializeEx` without restarting the
cheat.  On a broken device the console additionally shows the LeechCore probe,
e.g.

```
[dma] device 'fpga':
DEVICE: FPGA: ERROR: Unable to connect to FPGA device [0,v0.0,0000]
```

Common errors:

* `Unable to connect to FPGA device` — the FPGA is not visible over USB.
  Check the USB 3 cable/connector, card power, and that the FTDI **D3XX**
  driver is installed.  `FTD3XX.dll` is copied next to the exe by the build,
  but the kernel driver is a separate install.  With a two-PC setup the card
  sits in the game PC and the USB end must be on the cheat PC.
* `waiting for process ...` — `--process` is not the real exe name.  Use the
  name from Task Manager, e.g. `Crown-Win64-Shipping.exe`.
* No device at all — try another device string: `fpga://algo=2`, `usb3380`,
  `file://C:\dump.raw` (physical memory dump), or `pmem` (live RAM of the
  local PC, needs admin).

`--verbose` adds `-printf -vv` and prints LeechCore's device probing.
Run it without DMA hardware to see the failure reason:

```bat
crown_dma.exe --device fpga --verbose
```

## Updating offsets after a game patch

1. Run Il2CppDumper again against the new `GameAssembly.dll` and
   `global-metadata.dat`.
2. Replace `dump.cs` and `script.json` in this folder.
3. Regenerate the header:

```bat
python tools/gen_offsets.py
```

4. Rebuild.  If a field was renamed, the generator names the class/field it
   could not find instead of producing a silently wrong offset.

The generator extracts the field offsets from `dump.cs` and the metadata-usage
RVAs from `script.json`; it does not need the game binary itself.  The
`Il2CppClass` layout constants (`static_fields` at `0xB8`, object header size,
dictionary/string/array layouts) are in `src/game/memory.h` and are tied to the
Unity/IL2CPP version of this dump.

## Notes / limits

* The initial `VMMDLL_MemSearch` scans the process address space and can take
  tens of seconds on a slow DMA link.  The overlay shows the progress state and
  remains responsive.
* The ESP uses `BattleCharacterModel.transform` (feet) and a 1.85 m box height.
  `CenterPosition` is used for the aim-point dot.  Tune `boxWidthScale`/height
  in the menu if the boxes feel off for a specific character model.
* Wallhack writes are refreshed at ~20 Hz because the game's overlay updater
  recomputes several flags every frame.  If your FPGA is read-only, leave it
  off.
* The overlay draws in monitor coordinates.  It assumes the game is borderless
  fullscreen at the monitor resolution; windowed mode needs the viewport origin
  offset (already handled through `GetForegroundWindow`, but the menu itself
  steals foreground while open).
* No aimbot, triggerbot or input device support is included — this is an
  ESP/wallhack source only.  The menu is `zintix_menu.cpp`; it only exposes
  controls that are actually backed by the DMA reader.