#define NOMINMAX
#include <windows.h>

#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>

#include "game/game.h"
#include "render/esp.h"
#include "render/overlay.h"

namespace {

void PrintUsage() {
    std::cout
        << "crown dma - DMA ESP / wallhack overlay\n\n"
        << "usage: crown_dma [options]\n\n"
        << "  --process <name>     game process name (default: Crown.exe)\n"
        << "  --module <name>      IL2CPP module name (default: GameAssembly.dll)\n"
        << "  --device <device>    MemProcFS device, e.g. fpga, fpga://algo=2,\n"
        << "                       file://C:\\dump.raw (default: fpga)\n"
        << "  --dma-arg <arg>      extra argument passed to VMMDLL_Initialize\n"
        << "  --verbose            enable MemProcFS device diagnostics (-printf -vv)\n"
        << "  --help               this text\n\n"
        << "hotkeys: INS menu | F1 ESP | F2 wallhack | F3 names | F4 boxes\n"
        << "         F5 health | F6 distance | F7 snaplines\n";
}

bool EdgePressed(int vk, bool& previous) {
    const bool down = vk != 0 && (GetAsyncKeyState(vk) & 0x8000) != 0;
    const bool edge = down && !previous;
    previous = down;
    return edge;
}

struct KeyState {
    bool menu = false;
    bool f1 = false;
    bool f2 = false;
    bool f3 = false;
    bool f4 = false;
    bool f5 = false;
    bool f6 = false;
    bool f7 = false;
};

}  // namespace

int main(int argc, char** argv) {
    crown::GameOptions options;

    for (int i = 1; i < argc; ++i) {
        const std::string arg = argv[i];
        auto next = [&](const char* name) -> std::string {
            if (i + 1 >= argc) {
                std::cerr << "missing value for " << name << "\n";
                std::exit(2);
            }
            return argv[++i];
        };

        if (arg == "--help" || arg == "-h") {
            PrintUsage();
            return 0;
        } else if (arg == "--process") {
            options.processName = next("--process");
        } else if (arg == "--module") {
            options.moduleName = next("--module");
        } else if (arg == "--device") {
            options.dmaArgs.push_back("-device");
            options.dmaArgs.push_back(next("--device"));
        } else if (arg == "--dma-arg") {
            options.dmaArgs.push_back(next("--dma-arg"));
        } else if (arg == "--verbose") {
            options.dmaArgs.push_back("-printf");
            options.dmaArgs.push_back("-vv");
        } else {
            std::cerr << "unknown argument: " << arg << "\n";
            PrintUsage();
            return 2;
        }
    }

    std::cout << "crown dma\n";
    std::cout << "  process: " << options.processName << "\n";
    std::cout << "  module:  " << options.moduleName << "\n";

    crown::Game game;
    game.Start(options);

    crown::Overlay overlay;
    if (!overlay.Create(GetModuleHandleW(nullptr))) {
        std::cerr << "failed to create overlay\n";
        game.Stop();
        return 1;
    }

    crown::ApplyZintixStyle();

    crown::Esp esp;
    crown::EspSettings settings;
    KeyState keys;

    ULONGLONG lastFrame = GetTickCount64();

    while (!overlay.ShouldClose()) {
        if (EdgePressed(settings.menuKey, keys.menu)) {
            overlay.SetMenuOpen(!overlay.MenuOpen());
        }
        if (EdgePressed(VK_F1, keys.f1)) {
            settings.enabled = !settings.enabled;
        }
        if (EdgePressed(VK_F2, keys.f2)) {
            game.SetWallhack(!game.WallhackEnabled());
        }
        if (EdgePressed(VK_F3, keys.f3)) {
            settings.names = !settings.names;
        }
        if (EdgePressed(VK_F4, keys.f4)) {
            settings.boxes = !settings.boxes;
        }
        if (EdgePressed(VK_F5, keys.f5)) {
            settings.health = !settings.health;
        }
        if (EdgePressed(VK_F6, keys.f6)) {
            settings.distance = !settings.distance;
        }
        if (EdgePressed(VK_F7, keys.f7)) {
            settings.snaplines = !settings.snaplines;
        }

        ImGuiIO& io = ImGui::GetIO();
        io.MouseDrawCursor = overlay.MenuOpen();

        overlay.NewFrame();
        if (overlay.ShouldClose()) {
            break;
        }

        const crown::Snapshot snapshot = game.SnapshotCopy();
        esp.Draw(snapshot, settings, overlay.Width(), overlay.Height());
        if (overlay.MenuOpen()) {
            crown::RenderZintixMenu(settings, game, snapshot);
            if (settings.requestUnload) {
                overlay.RequestClose();
            }
        }
        overlay.SetStreamproof(settings.streamproof);
        overlay.Present(settings.vsync);

        if (settings.fpsLimit > 0) {
            const ULONGLONG target = 1000ull / static_cast<ULONGLONG>(settings.fpsLimit);
            const ULONGLONG elapsed = GetTickCount64() - lastFrame;
            if (elapsed < target) {
                Sleep(static_cast<DWORD>(target - elapsed));
            }
        }
        lastFrame = GetTickCount64();
    }

    overlay.Destroy();
    game.Stop();
    return 0;
}
