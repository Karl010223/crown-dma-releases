#pragma once

#define NOMINMAX
#include <windows.h>
#include <d3d11.h>

#include <cstdint>
#include <string>

struct ImGuiContext;

namespace crown {

class Overlay {
public:
    Overlay() = default;
    ~Overlay();

    Overlay(const Overlay&) = delete;
    Overlay& operator=(const Overlay&) = delete;

    bool Create(HINSTANCE instance, const std::wstring& title = L"Crown DMA");
    void Destroy();

    void NewFrame();
    void Present(bool vsync);

    void SetMenuOpen(bool open);
    bool MenuOpen() const { return menuOpen_; }
    bool ShouldClose() const { return shouldClose_; }
    void RequestClose() { shouldClose_ = true; }
    void SetStreamproof(bool enabled);

    int Width() const { return width_; }
    int Height() const { return height_; }
    HWND Handle() const { return hwnd_; }

private:
    static LRESULT CALLBACK WndProcStatic(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
    LRESULT WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

    HWND hwnd_ = nullptr;
    HWND previousForeground_ = nullptr;
    int width_ = 0;
    int height_ = 0;
    bool menuOpen_ = false;
    bool shouldClose_ = false;
    bool imguiReady_ = false;
    bool streamproof_ = false;

    ID3D11Device* device_ = nullptr;
    ID3D11DeviceContext* context_ = nullptr;
    IDXGISwapChain* swapChain_ = nullptr;
    ID3D11RenderTargetView* renderTarget_ = nullptr;
};

}  // namespace crown