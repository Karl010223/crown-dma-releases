cmake_minimum_required(VERSION 3.20)
project(crown_dma LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

if(NOT WIN32)
    message(FATAL_ERROR "crown_dma is a Windows-only DirectX overlay project")
endif()

# ---------------------------------------------------------------------------
# MemProcFS SDK
#
# Download the MemProcFS release for Windows x64 and point this at the folder
# that contains vmmdll.h, leechcore.h, vmm.lib and leechcore.lib, e.g.
#   -DMEMPROCFS_SDK=C:/Tools/MemProcFS/sdk
# ---------------------------------------------------------------------------
set(MEMPROCFS_SDK "" CACHE PATH "Folder containing the MemProcFS SDK headers and import libraries")

find_path(VMM_INCLUDE_DIR
    NAMES vmmdll.h
    HINTS
        ${MEMPROCFS_SDK}
        ${MEMPROCFS_SDK}/vmm
        ${MEMPROCFS_SDK}/sdk
        ${MEMPROCFS_SDK}/include
    REQUIRED
)

find_path(LEECHCORE_INCLUDE_DIR
    NAMES leechcore.h
    HINTS
        ${MEMPROCFS_SDK}
        ${MEMPROCFS_SDK}/vmm
        ${MEMPROCFS_SDK}/sdk
        ${MEMPROCFS_SDK}/include
    REQUIRED
)

find_library(VMM_LIBRARY
    NAMES vmm
    HINTS
        ${MEMPROCFS_SDK}
        ${MEMPROCFS_SDK}/vmm
        ${MEMPROCFS_SDK}/sdk
        ${MEMPROCFS_SDK}/lib
        ${MEMPROCFS_SDK}/lib/win-x64
    REQUIRED
)

find_library(LEECHCORE_LIBRARY
    NAMES leechcore
    HINTS
        ${MEMPROCFS_SDK}
        ${MEMPROCFS_SDK}/vmm
        ${MEMPROCFS_SDK}/sdk
        ${MEMPROCFS_SDK}/lib
        ${MEMPROCFS_SDK}/lib/win-x64
    REQUIRED
)

# ---------------------------------------------------------------------------
# Dear ImGui
# ---------------------------------------------------------------------------
include(FetchContent)
FetchContent_Declare(
    imgui
    URL https://github.com/ocornut/imgui/archive/refs/tags/v1.91.5.tar.gz
    DOWNLOAD_EXTRACT_TIMESTAMP TRUE
)
FetchContent_MakeAvailable(imgui)

add_library(imgui STATIC
    ${imgui_SOURCE_DIR}/imgui.cpp
    ${imgui_SOURCE_DIR}/imgui_draw.cpp
    ${imgui_SOURCE_DIR}/imgui_tables.cpp
    ${imgui_SOURCE_DIR}/imgui_widgets.cpp
    ${imgui_SOURCE_DIR}/backends/imgui_impl_dx11.cpp
    ${imgui_SOURCE_DIR}/backends/imgui_impl_win32.cpp
)
target_include_directories(imgui PUBLIC
    ${imgui_SOURCE_DIR}
    ${imgui_SOURCE_DIR}/backends
)
target_link_libraries(imgui PUBLIC d3d11 dxgi)

# ---------------------------------------------------------------------------
# Cheat
# ---------------------------------------------------------------------------
add_executable(crown_dma
    src/main.cpp
    src/dma/dma.cpp
    src/game/game.cpp
    src/render/overlay.cpp
    src/render/esp.cpp
    zintix_menu.cpp
)

target_include_directories(crown_dma PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}/src
    ${VMM_INCLUDE_DIR}
    ${LEECHCORE_INCLUDE_DIR}
)

target_link_libraries(crown_dma PRIVATE
    imgui
    ${VMM_LIBRARY}
    ${LEECHCORE_LIBRARY}
    d3d11
    dxgi
    dwmapi
)

if(MSVC)
    target_compile_options(crown_dma PRIVATE /W4 /permissive- /utf-8)
    target_compile_definitions(crown_dma PRIVATE _CRT_SECURE_NO_WARNINGS)
endif()

# Keep the MemProcFS runtime next to the executable when the SDK has the DLLs.
# FTD3XX is required for FPGA devices, tinylz4/dbghelp for the memory engine.
foreach(DLL_NAME vmm leechcore FTD3XX FTD3XXWU tinylz4 dbghelp symsrv vmmyara vcruntime140)
    foreach(DLL_DIR ${MEMPROCFS_SDK} ${MEMPROCFS_SDK}/vmm ${MEMPROCFS_SDK}/sdk ${MEMPROCFS_SDK}/lib)
        if(EXISTS "${DLL_DIR}/${DLL_NAME}.dll")
            add_custom_command(TARGET crown_dma POST_BUILD
                COMMAND ${CMAKE_COMMAND} -E copy_if_different
                    "${DLL_DIR}/${DLL_NAME}.dll"
                    "$<TARGET_FILE_DIR:crown_dma>/${DLL_NAME}.dll"
                VERBATIM
            )
        endif()
    endforeach()
endforeach()

message(STATUS "MemProcFS headers: ${VMM_INCLUDE_DIR}")
message(STATUS "MemProcFS libs:    ${VMM_LIBRARY}, ${LEECHCORE_LIBRARY}")