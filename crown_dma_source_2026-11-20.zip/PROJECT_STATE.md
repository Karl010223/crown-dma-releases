# Project state — crown dma

Last updated: 2026-11-20
Workspace: `C:\Users\Administrator\Desktop\crown dma`

This file is the resume point for this project.  Everything below is already
on disk and compiled.

## Status

* `build/Release/crown_dma.exe` builds clean (MSVC /W4, no warnings from our
  code).
* The only UI is `zintix_menu.cpp` (Zintix layout, title "Rob Run").
* Role ESP is implemented for **Police / Robber / Civil** (+ Prisoner / Clan).
* DMA device errors are reported with the exact LeechCore text and can be
  retried from the menu.

## What was changed in this session

| File | Change |
| --- | --- |
| `zintix_menu.cpp` | Rewritten as the cheat's only menu: Visuals, Roles, Miscellaneous (incl. DMA card + Reconnect), Configuration (config save/load, unload), SDK. Kept the Zintix style/cards. |
| `src/render/esp.h/.cpp` | New `EspSettings` (players, roles, colors, projection, interface, debug); role-filtered ESP, role labels, per-role colors, 2D/corner boxes, health, snaplines, status text. Old `Esp::DrawMenu` removed. |
| `src/game/game.h/.cpp` | `RoleTeam`, per-player role fields, exact role classification via `PlayerRoleDescriptions` static field table, id-string fallback, DMA error status, `RequestReconnect()`, `DmaError()`. |
| `src/dma/dma.h/.cpp` | `VMMDLL_InitializeEx` + extended error text; one-shot LeechCore diagnostic (`LcCreateEx` + printf callback) that prints e.g. `DEVICE: FPGA: ERROR: Unable to connect to FPGA device`; `LastError()`. |
| `src/main.cpp` | Uses the Zintix menu, `-printf -vv` via `--verbose`, FPS limiter, VSync, streamproof, unload, reconnect-safe loop. |
| `src/render/overlay.h/.cpp` | `Present(bool vsync)`, `SetStreamproof(bool)` (`SetWindowDisplayAffinity`), `RequestClose()`. |
| `tools/gen_offsets.py` | Added `PlayerRoleDescriptions` TypeInfo + the 7 role static-field offsets. |
| `src/game/offsets.h` | Regenerated: 69 field offsets, 20 TypeInfo slots. |
| `CMakeLists.txt` | Adds `zintix_menu.cpp`; copies runtime DLLs (vmm, leechcore, FTD3XX, tinylz4, dbghelp, …). |
| `README.md` | Menu/roles/config/streamproof/DMA troubleshooting. |

## Build

```bat
cmake -S . -B build -A x64 -DMEMPROCFS_SDK=external/memprocfs
cmake --build build --config Release
```

On this machine CMake is bundled with VS 18:
`C:\Program Files\Microsoft Visual Studio\18\Community\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe`

Output: `build/Release/crown_dma.exe` plus `vmm.dll`, `leechcore.dll`,
`FTD3XX.dll`, `tinylz4.dll`, `dbghelp.dll`, `symsrv.dll`, `vmmyara.dll`,
`vcruntime140.dll`.

## Run

```bat
crown_dma.exe --process Crown-Win64-Shipping.exe --device fpga
```

Use the real game exe name from Task Manager.  Borderless windowed mode.
`--verbose` adds `-printf -vv` for device diagnostics.

Hotkeys: INS menu, F1 ESP, F2 wallhack, F3 names, F4 boxes, F5 health,
F6 distance, F7 snaplines.  The menu key comes from the config (`menu_key`).

## Roles

`Models.References.Battle.PlayerRoleDescription` instances are created once in
the static class `Models.ReferencesProject.Descriptions.Battle.PlayerRoleDescriptions`.
The cheat reads the static field table (`+0x08` Settler, `+0x10` Citizen,
`+0x18` Robber, `+0x20` Cop, `+0x28` ClanBattleMember, `+0x30` Prisoner,
`+0x38` Hubber) and compares the character's role pointer exactly.

Character path used:
`BattleCharacterModel +0x40 Data -> +0x20 CommonData -> +0x20 Role (IPrimitiveData) -> +0x18 value`.

If the table is not ready, the raw `Identified.Id` string is matched
(`citizen`, `robber`, `cop`, `prisoner`, ...).

Mapping: Police = Cop, Robber = Robber, Civil = Citizen/Settler/Hubber,
Prisoner = Prisoner, Clan = ClanBattleMember (shown under "Unknown / other").

## DMA not connecting

Verified on this machine: there is **no FPGA / FTDI device** and **no D3XX
driver** installed.  `MemProcFS.exe -device fpga -v` reports
`Unable to connect to FPGA device`.  This is a hardware/driver situation, not
a code bug.

Checklist:
1. FPGA card powered and USB 3 cable to the cheat PC.
2. FTDI **D3XX** driver installed (FTD3XX.dll alone is not the driver).
3. Correct device string (`fpga`, `fpga://algo=2`, `usb3380`, ...).
4. Use the menu's **Reconnect DMA** after plugging in.

## Verified / unverified

Verified:
* Clean Release build, `--help`.
* Overlay + D3D11/ImGui renders (screen capture showed the status text).
* DMA failure path prints LeechCore's exact error.
* Role offsets/typeinfo generated from `dump.cs` / `script.json`.

Not verified (no game + DMA hardware on this machine):
* Live role pointer resolution and in-game ESP positions.
* Wallhack writes.
* Menu interaction with the real keyboard (synthetic key injection does not
  reach the app in this remote session; hotkeys use `GetAsyncKeyState` and work
  on a normal desktop).

## Next steps on the game PC

1. Run with `--verbose` and fix any device error shown.
2. Start a battle, open SDK → Runtime: `roles: exact` should show once the role
   table is read; `battle: 0x...` and `camera: valid` should appear.
3. Open Roles tab and enable/disable Robber/Civil/Police.
4. Only enable wallhack if the FPGA supports writes.