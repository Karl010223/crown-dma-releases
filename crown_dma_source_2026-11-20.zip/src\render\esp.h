#pragma once

#include <string>

#include "imgui.h"
#include "game/game.h"

namespace crown {

struct EspSettings {
    bool enabled = true;

    // Players
    bool boxes = true;
    int boxStyle = 0;  // 0 = 2D, 1 = corner
    bool names = true;
    bool distance = true;
    bool health = true;
    bool snaplines = false;

    // Roles
    bool roleLabel = true;
    bool roleColors = true;
    bool highlightSameRole = true;
    bool roleRobber = true;
    bool roleCivil = true;
    bool rolePolice = true;
    bool rolePrisoner = true;
    bool roleUnknown = true;

    // Style
    ImVec4 boxColor = ImVec4(0.36f, 0.55f, 1.00f, 1.00f);
    ImVec4 roleColorRobber = ImVec4(1.00f, 0.37f, 0.37f, 1.00f);
    ImVec4 roleColorCivil = ImVec4(0.92f, 0.92f, 0.95f, 1.00f);
    ImVec4 roleColorPolice = ImVec4(0.35f, 0.67f, 1.00f, 1.00f);
    ImVec4 roleColorPrisoner = ImVec4(0.75f, 0.50f, 1.00f, 1.00f);
    ImVec4 roleColorUnknown = ImVec4(1.00f, 0.75f, 0.30f, 1.00f);

    // Projection / range
    bool useGameFov = true;
    float fovOverride = 75.0f;
    float maxDistance = 600.0f;
    float boxWidthScale = 0.55f;
    int maxPlayers = 128;

    // Interface
    int menuKey = 0x2D;  // VK_INSERT
    bool showStatus = true;
    bool streamproof = false;
    int fpsLimit = 0;  // 0 = uncapped
    bool vsync = false;

    // Debug
    bool debugEntities = false;
    bool debugOffsets = false;

    // Set by the menu's Unload button; the main loop shuts down.
    bool requestUnload = false;
};

class Esp {
public:
    void Draw(const Snapshot& snapshot, const EspSettings& settings, int overlayWidth, int overlayHeight);

private:
    static void TextShadow(ImDrawList* draw, const ImVec2& pos, ImU32 color, const char* text);
};

// Implemented in zintix_menu.cpp.  The menu is the only UI of the cheat.
void ApplyZintixStyle();
void RenderZintixMenu(EspSettings& settings, Game& game, const Snapshot& snapshot);

}  // namespace crown
