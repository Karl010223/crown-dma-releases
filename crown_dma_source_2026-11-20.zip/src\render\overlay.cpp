#define NOMINMAX
#include <windows.h>
#include <d3d11.h>
#include <dwmapi.h>

#include "render/overlay.h"

#include <iostream>

#include "imgui.h"
#include "imgui_impl_dx11.h"
#include "imgui_impl_win32.h"

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

namespace crown {
namespace {
Overlay* g_overlay = nullptr;
constexpr wchar_t kClassName[] = L"CrownDMAOverlayWindow";
}  // namespace

Overlay::~Overlay() { Destroy(); }

bool Overlay::Create(HINSTANCE instance, const std::wstring& title) {
    width_ = GetSystemMetrics(SM_CXSCREEN);
    height_ = GetSystemMetrics(SM_CYSCREEN);
    if (width_ <= 0 || height_ <= 0) {
        return false;
    }

    WNDCLASSEXW wc = {};
    wc.cbSize = sizeof(wc);
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = &Overlay::WndProcStatic;
    wc.hInstance = instance;
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wc.hbrBackground = nullptr;
    wc.lpszClassName = kClassName;
    if (!RegisterClassExW(&wc)) {
        std::cerr << "[overlay] RegisterClassExW failed: " << GetLastError() << "\n";
        return false;
    }

    const DWORD exStyle = WS_EX_TOPMOST | WS_EX_TRANSPARENT | WS_EX_LAYERED |
                          WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE;
    hwnd_ = CreateWindowExW(exStyle, kClassName, title.c_str(), WS_POPUP,
                            0, 0, width_, height_, nullptr, nullptr, instance, nullptr);
    if (!hwnd_) {
        std::cerr << "[overlay] CreateWindowExW failed: " << GetLastError() << "\n";
        return false;
    }
    g_overlay = this;
    SetLayeredWindowAttributes(hwnd_, 0, 255, LWA_ALPHA);
    const MARGINS margins = {-1, -1, -1, -1};
    DwmExtendFrameIntoClientArea(hwnd_, &margins);
    ShowWindow(hwnd_, SW_SHOWNOACTIVATE);
    UpdateWindow(hwnd_);

    DXGI_SWAP_CHAIN_DESC sd = {};
    sd.BufferCount = 2;
    sd.BufferDesc.Width = width_;
    sd.BufferDesc.Height = height_;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferDesc.RefreshRate.Numerator = 60;
    sd.BufferDesc.RefreshRate.Denominator = 1;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = hwnd_;
    sd.SampleDesc.Count = 1;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
    sd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;

    const D3D_FEATURE_LEVEL levels[] = {D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0};
    D3D_FEATURE_LEVEL featureLevel = D3D_FEATURE_LEVEL_11_0;
    HRESULT hr = D3D11CreateDeviceAndSwapChain(
        nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, levels,
        static_cast<UINT>(std::size(levels)), D3D11_SDK_VERSION, &sd,
        &swapChain_, &device_, &featureLevel, &context_);
    if (FAILED(hr)) {
        std::cerr << "[overlay] D3D11CreateDeviceAndSwapChain failed: 0x" << std::hex << hr << std::dec << "\n";
        return false;
    }

    ID3D11Texture2D* backBuffer = nullptr;
    if (FAILED(swapChain_->GetBuffer(0, IID_PPV_ARGS(&backBuffer)))) {
        return false;
    }
    const HRESULT rtv = device_->CreateRenderTargetView(backBuffer, nullptr, &renderTarget_);
    backBuffer->Release();
    if (FAILED(rtv)) {
        return false;
    }

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    io.IniFilename = nullptr;
    ImGui::StyleColorsDark();
    ImGui::GetStyle().WindowRounding = 6.0f;

    char windowsDir[MAX_PATH] = {};
    GetWindowsDirectoryA(windowsDir, MAX_PATH);
    const std::string fontPath = std::string(windowsDir) + "\\Fonts\\segoeui.ttf";
    if (io.Fonts->AddFontFromFileTTF(fontPath.c_str(), 18.0f) == nullptr) {
        io.Fonts->AddFontDefault();
    }

    ImGui_ImplWin32_Init(hwnd_);
    ImGui_ImplDX11_Init(device_, context_);
    imguiReady_ = true;

    SetMenuOpen(false);
    return true;
}

void Overlay::Destroy() {
    if (imguiReady_) {
        ImGui_ImplDX11_Shutdown();
        ImGui_ImplWin32_Shutdown();
        ImGui::DestroyContext();
        imguiReady_ = false;
    }
    if (renderTarget_) {
        renderTarget_->Release();
        renderTarget_ = nullptr;
    }
    if (swapChain_) {
        swapChain_->Release();
        swapChain_ = nullptr;
    }
    if (context_) {
        context_->Release();
        context_ = nullptr;
    }
    if (device_) {
        device_->Release();
        device_ = nullptr;
    }
    if (hwnd_) {
        DestroyWindow(hwnd_);
        hwnd_ = nullptr;
    }
    UnregisterClassW(kClassName, GetModuleHandleW(nullptr));
    g_overlay = nullptr;
}

void Overlay::NewFrame() {
    MSG msg = {};
    while (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) {
        if (msg.message == WM_QUIT) {
            shouldClose_ = true;
        }
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }
    if (shouldClose_ || !imguiReady_) {
        return;
    }
    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();
}

void Overlay::Present(bool vsync) {
    if (shouldClose_ || !imguiReady_) {
        return;
    }
    ImGui::Render();
    const float clear[4] = {0.0f, 0.0f, 0.0f, 0.0f};
    context_->OMSetRenderTargets(1, &renderTarget_, nullptr);
    context_->ClearRenderTargetView(renderTarget_, clear);
    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
    swapChain_->Present(vsync ? 1 : 0, 0);
}

void Overlay::SetStreamproof(bool enabled) {
    if (!hwnd_ || streamproof_ == enabled) {
        return;
    }
    streamproof_ = enabled;
#ifndef WDA_EXCLUDEFROMCAPTURE
#define WDA_EXCLUDEFROMCAPTURE 0x00000011
#endif
    // Hides the overlay from screen capture / OBS; falls back to a no-op on
    // systems older than Windows 10 2004.
    if (SetWindowDisplayAffinity(hwnd_, enabled ? WDA_EXCLUDEFROMCAPTURE : WDA_NONE) == FALSE) {
        SetWindowDisplayAffinity(hwnd_, enabled ? WDA_MONITOR : WDA_NONE);
    }
}

void Overlay::SetMenuOpen(bool open) {
    if (menuOpen_ == open) {
        return;
    }
    if (open) {
        previousForeground_ = GetForegroundWindow();
    }
    menuOpen_ = open;
    if (!hwnd_) {
        return;
    }
    LONG_PTR ex = GetWindowLongPtrW(hwnd_, GWL_EXSTYLE);
    if (open) {
        ex &= ~static_cast<LONG_PTR>(WS_EX_TRANSPARENT | WS_EX_NOACTIVATE);
    } else {
        ex |= static_cast<LONG_PTR>(WS_EX_TRANSPARENT | WS_EX_NOACTIVATE);
    }
    SetWindowLongPtrW(hwnd_, GWL_EXSTYLE, ex);

    if (open) {
        SetForegroundWindow(hwnd_);
        SetFocus(hwnd_);
    } else if (previousForeground_) {
        SetForegroundWindow(previousForeground_);
        previousForeground_ = nullptr;
    }
}

LRESULT CALLBACK Overlay::WndProcStatic(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    if (g_overlay) {
        return g_overlay->WndProc(hwnd, msg, wParam, lParam);
    }
    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

LRESULT Overlay::WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    if (imguiReady_ && menuOpen_) {
        if (ImGui_ImplWin32_WndProcHandler(hwnd, msg, wParam, lParam)) {
            return 1;
        }
    }
    switch (msg) {
        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
        case WM_CLOSE:
            shouldClose_ = true;
            return 0;
        default:
            break;
    }
    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

}  // namespace crown