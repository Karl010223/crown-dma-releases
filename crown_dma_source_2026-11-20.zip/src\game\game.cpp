#define NOMINMAX
#include <windows.h>

#include "game/game.h"

#include <algorithm>
#include <cctype>
#include <iostream>
#include <unordered_map>

#include "game/offsets.h"

namespace crown {
namespace {

std::string Utf16ToUtf8(const std::wstring& value) {
    if (value.empty()) {
        return {};
    }
    const int size = WideCharToMultiByte(CP_UTF8, 0, value.data(), static_cast<int>(value.size()),
                                         nullptr, 0, nullptr, nullptr);
    if (size <= 0) {
        return {};
    }
    std::string out(static_cast<size_t>(size), '\0');
    WideCharToMultiByte(CP_UTF8, 0, value.data(), static_cast<int>(value.size()),
                        out.data(), size, nullptr, nullptr);
    return out;
}

uint64_t NowMs() {
    return static_cast<uint64_t>(GetTickCount64());
}

}  // namespace

Game::~Game() { Stop(); }

void Game::Start(const GameOptions& options) {
    if (running_.exchange(true)) {
        return;
    }
    options_ = options;
    worker_ = std::thread(&Game::Worker, this);
}

void Game::Stop() {
    running_ = false;
    if (worker_.joinable()) {
        worker_.join();
    }
    dma_.Close();
    dmaStarted_ = false;
}

Snapshot Game::SnapshotCopy() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return snapshot_;
}

std::string Game::DmaError() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return dmaError_;
}

bool Game::Connect() {
    if (!dmaStarted_) {
        if (!dma_.Initialize(options_.dmaArgs)) {
            const std::string error = dma_.LastError();
            connectStatus_ = error.empty() ? "waiting for DMA device" : "DMA: " + error;
            std::lock_guard<std::mutex> lock(mutex_);
            dmaError_ = error;
            return false;
        }
        dmaStarted_ = true;
        {
            std::lock_guard<std::mutex> lock(mutex_);
            dmaError_.clear();
        }
    }

    if (dma_.pid() == 0 && !dma_.Attach(options_.processName)) {
        connectStatus_ = "waiting for process " + options_.processName;
        return false;
    }

    if (dma_.moduleBase() == 0) {
        uint64_t base = 0;
        if (!dma_.GetModuleBase(options_.moduleName, base)) {
            connectStatus_ = "waiting for module " + options_.moduleName;
            return false;
        }
        std::cerr << "[game] module base: 0x" << std::hex << base << std::dec << "\n";
    }

    attached_ = true;
    return true;
}

bool Game::ResolveClass(uint64_t typeInfoRva, const char* simpleName, uint64_t& out) {
    out = 0;
    const uint64_t slot = dma_.moduleBase() + typeInfoRva;
    uint64_t klass = 0;
    if (!dma_.Read(slot, klass) || klass == 0) {
        return false;
    }
    std::string name;
    if (!dma_.ReadCString(klass + 0x10, name, 96) || name != simpleName) {
        return false;
    }
    out = klass;
    return true;
}

bool Game::ResolveClasses() {
    bool ok = true;
    auto resolve = [&](uint64_t rva, const char* name, uint64_t& out, bool required = true) {
        if (out) {
            return true;
        }
        if (!ResolveClass(rva, name, out)) {
            if (required) {
                ok = false;
            }
            return false;
        }
        if (!loggedClasses_) {
            std::cerr << "[game] " << name << " = 0x" << std::hex << out << std::dec << "\n";
        }
        return true;
    };

    resolve(typeinfo::BattleModel, "BattleModel", classes_.battleModel);
    resolve(typeinfo::BattleEntitiesModel, "BattleEntitiesModel", classes_.battleEntitiesModel);
    resolve(typeinfo::WorldEntitiesModel, "WorldEntitiesModel", classes_.worldEntitiesModel);
    resolve(typeinfo::BattleCharacterModel, "BattleCharacterModel", classes_.battleCharacterModel);
    resolve(typeinfo::BattleCharacterPrivateModel, "BattleCharacterPrivateModel", classes_.battleCharacterPrivateModel);
    resolve(typeinfo::HealthModel, "HealthModel", classes_.healthModel);
    resolve(typeinfo::CharacterTransformModel, "CharacterTransformModel", classes_.characterTransformModel);
    resolve(typeinfo::BattleCharacterSlotModel, "BattleCharacterSlotModel", classes_.battleCharacterSlotModel);
    resolve(typeinfo::BattleCharacterSlotData, "BattleCharacterSlotData", classes_.battleCharacterSlotData);
    resolve(typeinfo::ClientCharacterSlotsModel, "ClientCharacterSlotsModel", classes_.clientCharacterSlotsModel);
    resolve(typeinfo::BattleCameraModel, "BattleCameraModel", classes_.battleCameraModel);
    resolve(typeinfo::OverlayModel, "OverlayModel", classes_.overlayModel);
    resolve(typeinfo::PlayerEntityModel, "PlayerEntityModel", classes_.playerEntityModel);

    // Optional: only needed for cosmetic/skeleton/FOV features.
    resolve(typeinfo::TransformModel, "TransformModel", classes_.transformModel, false);
    resolve(typeinfo::SkeletonModel, "SkeletonModel", classes_.skeletonModel, false);
    resolve(typeinfo::CinemachineBrain, "CinemachineBrain", classes_.cinemachineBrain, false);
    resolve(typeinfo::CharacterOverlayModel, "CharacterOverlayModel", classes_.characterOverlayModel, false);
    resolve(typeinfo::PlayerRoleDescription, "PlayerRoleDescription", classes_.playerRoleDescription, false);
    resolve(typeinfo::PlayerRoleDescriptions, "PlayerRoleDescriptions", classes_.playerRoleDescriptions, false);
    resolve(typeinfo::IntData, "IntData", classes_.intData, false);

    if (ok && !loggedClasses_) {
        loggedClasses_ = true;
    }
    return ok;
}

bool Game::ResolveRoleDescriptions() {
    if (!classes_.playerRoleDescriptions) {
        return false;
    }
    // PlayerRoleDescriptions is a static class; the role instances live in its
    // static field blob (offsets generated into offsets.h).
    const uint64_t statics = ReadPtr(classes_.playerRoleDescriptions + layout::kIl2CppClassStaticFields);
    if (!statics) {
        return false;
    }
    RoleSet roles;
    roles.settler = ReadPtr(statics + offsets::PlayerRoleDescriptions_Settler);
    roles.citizen = ReadPtr(statics + offsets::PlayerRoleDescriptions_Citizen);
    roles.robber = ReadPtr(statics + offsets::PlayerRoleDescriptions_Robber);
    roles.cop = ReadPtr(statics + offsets::PlayerRoleDescriptions_Cop);
    roles.clanBattleMember = ReadPtr(statics + offsets::PlayerRoleDescriptions_ClanBattleMember);
    roles.prisoner = ReadPtr(statics + offsets::PlayerRoleDescriptions_Prisoner);
    roles.hubber = ReadPtr(statics + offsets::PlayerRoleDescriptions_Hubber);
    if (!roles.valid()) {
        return false;
    }
    roles_ = roles;
    std::cerr << "[game] roles: citizen=0x" << std::hex << roles_.citizen
              << " robber=0x" << roles_.robber << " cop=0x" << roles_.cop << std::dec << "\n";
    return true;
}

bool Game::IsClass(uint64_t object, uint64_t klass) const {
    return object != 0 && klass != 0 && ReadPtr(object) == klass;
}

uint64_t Game::ReadPtr(uint64_t address) const {
    uint64_t value = 0;
    return dma_.Read(address, value) ? value : 0;
}

int Game::ReadInt(uint64_t address) const {
    int value = 0;
    dma_.Read(address, value);
    return value;
}

float Game::ReadFloat(uint64_t address) const {
    float value = 0.0f;
    dma_.Read(address, value);
    return value;
}

bool Game::ReadVec3(uint64_t address, Vec3& out) const {
    return dma_.Read(address, out);
}

bool Game::ReadQuat(uint64_t address, Quat& out) const {
    return dma_.Read(address, out);
}

std::string Game::ReadManagedString(uint64_t stringObject) const {
    if (!stringObject) {
        return {};
    }
    int length = 0;
    if (!dma_.Read(stringObject + layout::kStringLength, length) || length <= 0 || length > 256) {
        return {};
    }
    std::wstring wide(static_cast<size_t>(length), L'\0');
    const size_t bytes = static_cast<size_t>(length) * sizeof(wchar_t);
    if (!dma_.Read(stringObject + layout::kStringChars, wide.data(), bytes)) {
        return {};
    }
    return Utf16ToUtf8(wide);
}

bool Game::ReadPosition(uint64_t transform, Vec3& out) const {
    if (!transform) {
        return false;
    }
    const uint64_t klass = ReadPtr(transform);
    if (klass == classes_.characterTransformModel) {
        return dma_.Read(transform + offsets::CharacterTransformModel_X, out.x) &&
               dma_.Read(transform + offsets::CharacterTransformModel_Y, out.y) &&
               dma_.Read(transform + offsets::CharacterTransformModel_Z, out.z);
    }
    if (klass == classes_.transformModel) {
        const uint64_t x = ReadPtr(transform + offsets::TransformModel_X);
        const uint64_t y = ReadPtr(transform + offsets::TransformModel_Y);
        const uint64_t z = ReadPtr(transform + offsets::TransformModel_Z);
        if (!x || !y || !z) {
            return false;
        }
        return dma_.Read(x + layout::kPrimitiveValue, out.x) &&
               dma_.Read(y + layout::kPrimitiveValue, out.y) &&
               dma_.Read(z + layout::kPrimitiveValue, out.z);
    }
    return false;
}

bool Game::ReadHealth(uint64_t characterModel, int& amount, int& maxAmount, bool& dead) const {
    amount = 0;
    maxAmount = 100;
    dead = false;

    const uint64_t deadModel = ReadPtr(characterModel + offsets::BattleCharacterModel_IsDead);
    if (deadModel) {
        const uint64_t deadData = ReadPtr(deadModel + 0x10);
        if (deadData) {
            bool value = false;
            if (dma_.Read(deadData + layout::kPrimitiveValue, value)) {
                dead = value;
            }
        }
    }

    const uint64_t privateModel = ReadPtr(characterModel + offsets::BattleCharacterModel_PrivateModel);
    if (!privateModel || !IsClass(privateModel, classes_.battleCharacterPrivateModel)) {
        return false;
    }
    const uint64_t healthModel = ReadPtr(privateModel + offsets::BattleCharacterPrivateModel_Health);
    if (!healthModel || !IsClass(healthModel, classes_.healthModel)) {
        return false;
    }
    const uint64_t healthData = ReadPtr(healthModel + offsets::HealthModel_Health);
    if (healthData) {
        dma_.Read(healthData + layout::kPrimitiveValue, amount);
    }
    dma_.Read(healthModel + offsets::HealthModel_MaxAmount, maxAmount);
    if (maxAmount <= 0 || maxAmount > 100000) {
        maxAmount = 100;
    }
    if (amount < 0 || amount > 100000) {
        amount = 0;
    }
    return true;
}

std::string Game::ReadRoleId(uint64_t characterModel, uint64_t& roleObject) const {
    roleObject = 0;
    const uint64_t data = ReadPtr(characterModel + offsets::BattleCharacterModel_Data);
    if (!data) {
        return {};
    }
    const uint64_t common = ReadPtr(data + 0x20);  // BattleCharacterData::CommonData
    if (!common) {
        return {};
    }
    const uint64_t rolePrimitive = ReadPtr(common + 0x20);  // BattleCharacterCommonData::Role
    if (!rolePrimitive) {
        return {};
    }
    roleObject = ReadPtr(rolePrimitive + layout::kPrimitiveValue);
    if (!roleObject) {
        return {};
    }
    const uint64_t idString = ReadPtr(roleObject + offsets::Identified_Id);
    return ReadManagedString(idString);
}

void Game::ClassifyRole(PlayerData& player) const {
    player.roleTeam = RoleTeam::Unknown;
    player.roleLabel = "UNKNOWN";

    // Exact match against the game's own role instances.
    if (roles_.valid() && player.roleObject) {
        if (player.roleObject == roles_.cop) {
            player.roleTeam = RoleTeam::Police;
            player.roleLabel = "POLICE";
            return;
        }
        if (player.roleObject == roles_.robber) {
            player.roleTeam = RoleTeam::Robber;
            player.roleLabel = "ROBBER";
            return;
        }
        if (player.roleObject == roles_.prisoner) {
            player.roleTeam = RoleTeam::Prisoner;
            player.roleLabel = "PRISONER";
            return;
        }
        if (player.roleObject == roles_.clanBattleMember) {
            player.roleTeam = RoleTeam::Clan;
            player.roleLabel = "CLAN";
            return;
        }
        if (player.roleObject == roles_.citizen || player.roleObject == roles_.settler ||
            player.roleObject == roles_.hubber) {
            player.roleTeam = RoleTeam::Civil;
            player.roleLabel = "CIVIL";
            return;
        }
    }

    // Fallback: classify by the role id string if the static role table was not
    // available yet (e.g. during the first frames of a battle).
    std::string id = player.roleId;
    std::transform(id.begin(), id.end(), id.begin(),
                   [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    if (id.empty()) {
        return;
    }
    if (id.find("cop") != std::string::npos || id.find("police") != std::string::npos) {
        player.roleTeam = RoleTeam::Police;
        player.roleLabel = "POLICE";
    } else if (id.find("robber") != std::string::npos || id.find("bandit") != std::string::npos) {
        player.roleTeam = RoleTeam::Robber;
        player.roleLabel = "ROBBER";
    } else if (id.find("prison") != std::string::npos) {
        player.roleTeam = RoleTeam::Prisoner;
        player.roleLabel = "PRISONER";
    } else if (id.find("clan") != std::string::npos) {
        player.roleTeam = RoleTeam::Clan;
        player.roleLabel = "CLAN";
    } else if (id.find("citizen") != std::string::npos || id.find("civil") != std::string::npos ||
               id.find("settler") != std::string::npos || id.find("hub") != std::string::npos) {
        player.roleTeam = RoleTeam::Civil;
        player.roleLabel = "CIVIL";
    }
}

std::string Game::ReadNickname(uint64_t slotByEntityId, int entityId) const {
    if (!slotByEntityId) {
        return {};
    }
    uint64_t slot = 0;
    ForEachDictionaryEntry(slotByEntityId, [&](uint64_t key, uint64_t value) {
        if (static_cast<int>(key) == entityId) {
            slot = value;
        }
    });
    if (!slot || !IsClass(slot, classes_.battleCharacterSlotModel)) {
        return {};
    }
    const uint64_t data = ReadPtr(slot + offsets::BattleCharacterSlotModel_Data);
    if (!data || !IsClass(data, classes_.battleCharacterSlotData)) {
        return {};
    }
    const uint64_t nickname = ReadPtr(data + offsets::BattleCharacterSlotData_Nickname);
    if (!nickname) {
        return {};
    }
    return ReadManagedString(ReadPtr(nickname + layout::kPrimitiveValue));
}

void Game::ForEachDictionaryEntry(
    uint64_t dictionary,
    const std::function<void(uint64_t key, uint64_t value)>& callback) const {
    if (!dictionary) {
        return;
    }
    const uint64_t entries = ReadPtr(dictionary + layout::kDictEntries);
    if (!entries) {
        return;
    }
    const int count = ReadInt(dictionary + layout::kDictCount);
    int capacity = 0;
    if (!dma_.Read(entries + layout::kArrayLength, capacity) || capacity <= 0) {
        return;
    }
    capacity = std::min(capacity, 65536);
    const int limit = std::min(capacity, std::max(count, 1) + 64);
    const uint64_t data = entries + layout::kArrayData;
    for (int i = 0; i < limit; ++i) {
        const uint64_t entry = data + static_cast<uint64_t>(i) * layout::kDictEntrySize;
        int hash = 0;
        if (!dma_.Read(entry + layout::kDictEntryHash, hash) || hash < 0) {
            continue;
        }
        uint64_t key = 0;
        if (!dma_.Read(entry + layout::kDictEntryKey, key)) {
            continue;
        }
        const uint64_t value = ReadPtr(entry + layout::kDictEntryValue);
        if (value) {
            callback(key, value);
        }
    }
}

bool Game::ValidateBattleModel(uint64_t object) const {
    if (!IsClass(object, classes_.battleModel)) {
        return false;
    }
    const uint64_t battleEntities = ReadPtr(object + offsets::BattleModel_BattleEntitiesModel);
    if (!IsClass(battleEntities, classes_.battleEntitiesModel)) {
        return false;
    }
    const uint64_t world = ReadPtr(battleEntities + offsets::BattleEntitiesModel_WorldEntitiesModel);
    if (!IsClass(world, classes_.worldEntitiesModel)) {
        return false;
    }
    return true;
}

bool Game::ValidateBrain(uint64_t object) const {
    if (!IsClass(object, classes_.cinemachineBrain)) {
        return false;
    }
    const uint64_t outputCamera = ReadPtr(object + offsets::CinemachineBrain_OutputCamera);
    if (!outputCamera) {
        return false;
    }
    const float fov = ReadFloat(object + offsets::CinemachineBrain_CameraState +
                                offsets::CameraState_Lens + offsets::LensSettings_FieldOfView);
    return fov > 1.0f && fov < 179.0f;
}

bool Game::FindBattleModel() {
    if (!classes_.battleModel || !classes_.battleEntitiesModel || !classes_.worldEntitiesModel) {
        return false;
    }

    std::vector<uint64_t> patterns{classes_.battleModel};
    if (classes_.cinemachineBrain) {
        patterns.push_back(classes_.cinemachineBrain);
    }

    bool foundBattle = false;
    uint64_t foundBrain = brain_;
    const bool found = dma_.Search(patterns, [&](uint64_t address, int index) {
        if (index == 0) {
            if (!foundBattle && ValidateBattleModel(address)) {
                foundBattle = true;
                battleModel_ = address;
            }
            // Stop as soon as the battle model is located.  The brain is a
            // nice-to-have for exact FOV; it is usually allocated earlier and
            // therefore seen first by the search.
            return !foundBattle;
        }
        if (index == 1 && !foundBrain && ValidateBrain(address)) {
            foundBrain = address;
        }
        return !(foundBattle || foundBrain);
    });

    (void)found;
    if (foundBrain) {
        brain_ = foundBrain;
    }
    if (battleModel_) {
        const uint64_t battleEntities = ReadPtr(battleModel_ + offsets::BattleModel_BattleEntitiesModel);
        worldEntities_ = ReadPtr(battleEntities + offsets::BattleEntitiesModel_WorldEntitiesModel);
        std::cerr << "[game] BattleModel = 0x" << std::hex << battleModel_
                  << "  Brain = 0x" << brain_ << std::dec << "\n";
        return true;
    }

    nextSearchAt_ = NowMs() + 4000;
    return false;
}

void Game::ApplyWallhack(const Snapshot& snapshot, uint64_t battleEntities, uint64_t battleModel) {
    (void)battleEntities;

    // Make the game's built-in nickname overlay treat every role as
    // "visible through wall".  The updater still recomputes some flags, so the
    // per-overlay flags are refreshed below at ~20 Hz.
    for (const auto& player : snapshot.players) {
        if (player.roleObject && patchedRoles_.insert(player.roleObject).second) {
            const bool enabled = true;
            dma_.Write(player.roleObject + offsets::PlayerRoleDescription_NicknameThroughWall, &enabled, 1);
        }
    }

    if (NowMs() < nextWallhackAt_) {
        return;
    }
    nextWallhackAt_ = NowMs() + 50;

    const uint64_t overlay = ReadPtr(battleModel + offsets::BattleModel_OverlayModel);
    if (!overlay || !IsClass(overlay, classes_.overlayModel)) {
        return;
    }
    const uint64_t dict = ReadPtr(overlay + offsets::OverlayModel_OverlayDict);
    if (!dict) {
        return;
    }

    const bool enabled = true;
    const float alpha = 1.0f;
    ForEachDictionaryEntry(dict, [&](uint64_t, uint64_t value) {
        if (!value || !IsClass(value, classes_.characterOverlayModel)) {
            return;
        }
        dma_.Write(value + offsets::CharacterOverlayModel_IsVisible, &enabled, 1);
        dma_.Write(value + offsets::CharacterOverlayModel_IsNicknameVisible, &enabled, 1);
        dma_.Write(value + 0x58, &alpha, sizeof(alpha));   // NicknameContainerAlpha
        dma_.Write(value + 0x5C, &enabled, 1);             // IsInNicknameDistance
    });
}

void Game::Worker() {
    Snapshot empty;
    empty.status = "waiting for DMA";

    while (running_) {
        if (reconnect_.exchange(false)) {
            dma_.Close();
            dmaStarted_ = false;
            attached_ = false;
            connectStatus_ = "reconnecting DMA";
            std::lock_guard<std::mutex> lock(mutex_);
            snapshot_ = empty;
            snapshot_.status = connectStatus_;
        }

        if (!Connect()) {
            std::lock_guard<std::mutex> lock(mutex_);
            snapshot_ = empty;
            snapshot_.status = connectStatus_;
            Sleep(1000);
            continue;
        }

        if (!ResolveClasses()) {
            std::lock_guard<std::mutex> lock(mutex_);
            snapshot_ = empty;
            snapshot_.attached = true;
            snapshot_.status = "waiting for IL2CPP metadata";
            Sleep(1000);
            continue;
        }

        if (!roles_.valid() && NowMs() >= nextRoleResolveAt_) {
            nextRoleResolveAt_ = NowMs() + 1000;
            ResolveRoleDescriptions();
        }

        if (!battleModel_ || !ValidateBattleModel(battleModel_)) {
            battleModel_ = 0;
            worldEntities_ = 0;
            if (NowMs() >= nextSearchAt_) {
                {
                    std::lock_guard<std::mutex> lock(mutex_);
                    snapshot_ = empty;
                    snapshot_.attached = true;
                    snapshot_.status = "searching for BattleModel (DMA heap scan)";
                }
                FindBattleModel();
            }
            if (!battleModel_) {
                std::lock_guard<std::mutex> lock(mutex_);
                snapshot_ = empty;
                snapshot_.attached = true;
                snapshot_.status = "not in battle";
                Sleep(250);
                continue;
            }
        }

        Snapshot s;
        s.attached = true;
        s.battleModel = battleModel_;
        s.rolesResolved = roles_.valid();

        const uint64_t battleEntities = ReadPtr(battleModel_ + offsets::BattleModel_BattleEntitiesModel);
        if (!IsClass(battleEntities, classes_.battleEntitiesModel)) {
            battleModel_ = 0;
            Sleep(50);
            continue;
        }

        const uint64_t world = ReadPtr(battleEntities + offsets::BattleEntitiesModel_WorldEntitiesModel);
        if (!IsClass(world, classes_.worldEntitiesModel)) {
            battleModel_ = 0;
            Sleep(50);
            continue;
        }
        worldEntities_ = world;

        // Camera / projection
        const uint64_t camera = ReadPtr(battleModel_ + offsets::BattleModel_BattleCameraModel);
        if (IsClass(camera, classes_.battleCameraModel)) {
            ReadVec3(camera + offsets::BattleCameraModel_Position, s.cameraPosition);
            ReadVec3(camera + offsets::BattleCameraModel_Forward, s.cameraForward);
            ReadVec3(camera + offsets::BattleCameraModel_Right, s.cameraRight);
            ReadVec3(camera + offsets::BattleCameraModel_Up, s.cameraUp);
            if (Length(s.cameraForward) < 0.5f || Length(s.cameraRight) < 0.5f || Length(s.cameraUp) < 0.5f) {
                Quat orientation;
                if (ReadQuat(camera + offsets::BattleCameraModel_Orientation, orientation)) {
                    s.cameraForward = Forward(orientation);
                    s.cameraRight = Right(orientation);
                    s.cameraUp = Up(orientation);
                }
            }
            s.cameraForward = Normalize(s.cameraForward);
            s.cameraRight = Normalize(s.cameraRight);
            s.cameraUp = Normalize(s.cameraUp);
            s.cameraValid = Length(s.cameraForward) > 0.5f;
        }

        if (brain_ && ValidateBrain(brain_)) {
            const float fov = ReadFloat(brain_ + offsets::CinemachineBrain_CameraState +
                                        offsets::CameraState_Lens + offsets::LensSettings_FieldOfView);
            if (fov > 1.0f && fov < 179.0f) {
                s.cameraFov = fov;
                s.fovFromGame = true;
            }
        }

        // Local player
        uint64_t localModel = 0;
        const uint64_t playerEntity = ReadPtr(battleEntities + offsets::BattleEntitiesModel_Player);
        if (IsClass(playerEntity, classes_.playerEntityModel)) {
            const uint64_t serverModel = ReadPtr(playerEntity + offsets::PlayerEntityModel_ServerModel);
            if (IsClass(serverModel, classes_.battleCharacterModel)) {
                localModel = serverModel;
                s.localId = ReadInt(localModel + offsets::BattleCharacterModel_Id);
                const uint64_t localTransform = ReadPtr(localModel + offsets::BattleCharacterModel_Transform);
                ReadPosition(localTransform, s.localPosition);
            }
        }

        // Names live in the client slot registry, not in the ECS character model.
        uint64_t slotByEntityId = 0;
        const uint64_t slotRoot = ReadPtr(battleEntities + offsets::BattleEntitiesModel_CharacterSlotModel);
        if (IsClass(slotRoot, classes_.clientCharacterSlotsModel)) {
            slotByEntityId = ReadPtr(slotRoot + offsets::ClientCharacterSlotsModel_SlotByEntityId);
        }

        std::string localRole;
        uint64_t localRoleObject = 0;
        if (localModel) {
            localRole = ReadRoleId(localModel, localRoleObject);
        }

        const uint64_t characters = ReadPtr(world + offsets::WorldEntitiesModel_BattleCharacters);
        if (characters) {
            ForEachDictionaryEntry(characters, [&](uint64_t key, uint64_t value) {
                const int id = static_cast<int>(key);
                if (!value || !IsClass(value, classes_.battleCharacterModel)) {
                    return;
                }
                if (value == localModel) {
                    return;
                }

                PlayerData p;
                p.id = id;
                const uint64_t transform = ReadPtr(value + offsets::BattleCharacterModel_Transform);
                if (!ReadPosition(transform, p.position)) {
                    return;
                }
                dma_.Read(value + offsets::BattleCharacterModel_CenterPosition, p.center);

                bool dead = false;
                ReadHealth(value, p.health, p.maxHealth, dead);
                p.dead = dead || p.health <= 0;
                if (p.dead) {
                    return;
                }

                p.roleId = ReadRoleId(value, p.roleObject);
                ClassifyRole(p);
                p.sameRole = (localRoleObject != 0 && p.roleObject == localRoleObject) ||
                             (!localRole.empty() && p.roleId == localRole);
                p.name = ReadNickname(slotByEntityId, id);
                p.nameKnown = !p.name.empty();
                s.players.push_back(std::move(p));
            });
        }

        if (wallhack_) {
            ApplyWallhack(s, battleEntities, battleModel_);
        }

        s.inBattle = localModel != 0;
        s.status = s.inBattle ? "in battle" : "not spawned yet";

        {
            std::lock_guard<std::mutex> lock(mutex_);
            snapshot_ = std::move(s);
        }
        Sleep(4);
    }
}

}  // namespace crown