#pragma once

#include <cmath>
#include <cstdint>

namespace crown {

// ---------------------------------------------------------------------------
// Managed object layout constants for the Unity/IL2CPP version this dump was
// produced with.  The class-specific offsets are generated into offsets.h.
// ---------------------------------------------------------------------------
namespace layout {
constexpr uint32_t kIl2CppClassStaticFields = 0xB8;  // Il2CppClass::static_fields
constexpr uint32_t kPrimitiveValue = 0x18;           // BasePrimitiveData<T>::_value
constexpr uint32_t kPrimitiveSerializer = 0x10;      // BasePrimitiveData<T>::_serializer
constexpr uint32_t kArrayLength = 0x18;              // Il2CppArray::max_length
constexpr uint32_t kArrayData = 0x20;                // first array element
constexpr uint32_t kStringLength = 0x10;             // System.String::_stringLength
constexpr uint32_t kStringChars = 0x14;              // System.String::_firstChar
constexpr uint32_t kDictEntries = 0x18;              // Dictionary::_entries
constexpr uint32_t kDictCount = 0x20;                // Dictionary::_count
constexpr uint32_t kDictEntrySize = 24;              // ref value, 8-byte aligned
constexpr uint32_t kDictEntryKey = 8;
constexpr uint32_t kDictEntryValue = 16;
constexpr uint32_t kDictEntryHash = 0;
}  // namespace layout

struct Vec2 {
    float x = 0.0f;
    float y = 0.0f;
};

struct Vec3 {
    float x = 0.0f;
    float y = 0.0f;
    float z = 0.0f;
};

struct Quat {
    float x = 0.0f;
    float y = 0.0f;
    float z = 0.0f;
    float w = 1.0f;
};

inline Vec3 operator+(const Vec3& a, const Vec3& b) { return {a.x + b.x, a.y + b.y, a.z + b.z}; }
inline Vec3 operator-(const Vec3& a, const Vec3& b) { return {a.x - b.x, a.y - b.y, a.z - b.z}; }
inline Vec3 operator*(const Vec3& a, float s) { return {a.x * s, a.y * s, a.z * s}; }

inline float Dot(const Vec3& a, const Vec3& b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
inline float Length(const Vec3& a) { return std::sqrt(Dot(a, a)); }

inline Vec3 Cross(const Vec3& a, const Vec3& b) {
    return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x};
}

inline Vec3 Normalize(const Vec3& a) {
    const float len = Length(a);
    return len > 1e-6f ? a * (1.0f / len) : Vec3{};
}

inline Quat Normalize(const Quat& q) {
    const float len = std::sqrt(q.x * q.x + q.y * q.y + q.z * q.z + q.w * q.w);
    if (len < 1e-6f) {
        return {};
    }
    const float inv = 1.0f / len;
    return {q.x * inv, q.y * inv, q.z * inv, q.w * inv};
}

inline Vec3 Rotate(const Quat& q, const Vec3& v) {
    const Vec3 u{q.x, q.y, q.z};
    const float s = q.w;
    return u * (2.0f * Dot(u, v)) + v * (s * s - Dot(u, u)) + Cross(u, v) * (2.0f * s);
}

inline Vec3 Forward(const Quat& q) { return Normalize(Rotate(q, {0.0f, 0.0f, 1.0f})); }
inline Vec3 Right(const Quat& q) { return Normalize(Rotate(q, {1.0f, 0.0f, 0.0f})); }
inline Vec3 Up(const Quat& q) { return Normalize(Rotate(q, {0.0f, 1.0f, 0.0f})); }

}  // namespace crown