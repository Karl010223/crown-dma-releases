#!/usr/bin/env python3
"""
Generates src/game/offsets.h from the Il2CppDumper output in the repository root.

Usage:
    python tools/gen_offsets.py [--dump ../dump.cs] [--script ../script.json] [--out src/game/offsets.h]

The generated file contains:
  * instance field offsets (relative to the managed object) for the classes the
    cheat reads every frame;
  * metadata-usage RVAs for the Il2CppClass* ("TypeInfo") slots, which are read
    from GameAssembly.dll at runtime to resolve the class pointers.

If Il2CppDumper renames a backing field in a future game update the script
prints a readable error instead of silently emitting a wrong offset.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

# (constant suffix, declaring class, field name)
FIELD_SPECS = [
    # Battle / entity graph
    ("BattleModel_BattleEntitiesModel", "Game.Battle.BattleModel", "<BattleEntitiesModel>k__BackingField"),
    ("BattleModel_BattleCameraModel", "Game.Battle.BattleModel", "<BattleCameraModel>k__BackingField"),
    ("BattleModel_OverlayModel", "Game.Battle.BattleModel", "<OverlayModel>k__BackingField"),
    ("BattleEntitiesModel_Models", "Game.Battle.BattleEntitiesModel", "_models"),
    ("BattleEntitiesModel_WorldEntitiesModel", "Game.Battle.BattleEntitiesModel", "_worldEntitiesModel"),
    ("BattleEntitiesModel_CharacterSlotModel", "Game.Battle.BattleEntitiesModel", "_characterSlotModel"),
    ("BattleEntitiesModel_Player", "Game.Battle.BattleEntitiesModel", "<Player>k__BackingField"),
    ("WorldEntitiesModel_BattleCharacters", "Models.Models.WorldEntities.WorldEntitiesModel", "_battleCharacters"),

    # Character model
    ("BattleCharacterModel_PrivateModel", "Models.Models.BattleCharacter.BattleCharacterModel", "<PrivateModel>k__BackingField"),
    ("BattleCharacterModel_Id", "Models.Models.BattleCharacter.BattleCharacterModel", "<Id>k__BackingField"),
    ("BattleCharacterModel_Data", "Models.Models.BattleCharacter.BattleCharacterModel", "<Data>k__BackingField"),
    ("BattleCharacterModel_Transform", "Models.Models.BattleCharacter.BattleCharacterModel", "<Transform>k__BackingField"),
    ("BattleCharacterModel_IsDead", "Models.Models.BattleCharacter.BattleCharacterModel", "<IsDead>k__BackingField"),
    ("BattleCharacterModel_SkeletonModel", "Models.Models.BattleCharacter.BattleCharacterModel", "<SkeletonModel>k__BackingField"),
    ("BattleCharacterModel_Role", "Models.Models.BattleCharacter.BattleCharacterModel", "<Role>k__BackingField"),
    ("BattleCharacterModel_CenterPosition", "Models.Models.BattleCharacter.BattleCharacterModel", "<CenterPosition>k__BackingField"),

    ("PlayerEntityModel_ServerModel", "Game.Battle.EntityModel.Player.PlayerEntityModel", "<ServerModel>k__BackingField"),

    # Health
    ("BattleCharacterPrivateModel_Health", "Models.Models.BattleCharacterPrivate.BattleCharacterPrivateModel", "<Health>k__BackingField"),
    ("HealthModel_Health", "Models.Models.Health.HealthModel", "_health"),
    ("HealthModel_MaxAmount", "Models.Models.Health.HealthModel", "_maxAmount"),

    # Transform (server model can use either of these implementations)
    ("CharacterTransformModel_X", "Models.Models.TransformModel.CharacterTransformModel", "<X>k__BackingField"),
    ("CharacterTransformModel_Y", "Models.Models.TransformModel.CharacterTransformModel", "<Y>k__BackingField"),
    ("CharacterTransformModel_Z", "Models.Models.TransformModel.CharacterTransformModel", "<Z>k__BackingField"),
    ("TransformModel_X", "Models.Models.TransformModel.TransformModel", "_x"),
    ("TransformModel_Y", "Models.Models.TransformModel.TransformModel", "_y"),
    ("TransformModel_Z", "Models.Models.TransformModel.TransformModel", "_z"),

    # Skeleton (optional skeleton ESP)
    ("SkeletonModel_Description", "Models.Models.Skeleton.SkeletonModel", "_skeletonDescription"),
    ("SkeletonModel_BonesData", "Models.Models.Skeleton.SkeletonModel", "_bonesData"),
    ("SkeletonConfig_BoneDataSize", "Models.References.Character.SkeletonConfig", "<BoneDataSize>k__BackingField"),
    ("SkeletonConfig_LocalOffset", "Models.References.Character.SkeletonConfig", "<BoneDataLocalPositionOrientationOffset>k__BackingField"),
    ("SkeletonConfig_ModelOffset", "Models.References.Character.SkeletonConfig", "<BoneDataModelOrientationOffset>k__BackingField"),
    ("SkeletonConfig_LengthOffset", "Models.References.Character.SkeletonConfig", "<BoneDataLengthOffset>k__BackingField"),
    ("SkeletonConfig_Hierarchy", "Models.References.Character.SkeletonConfig", "<BonesHierarchyData>k__BackingField"),
    ("SkeletonConfig_Root", "Models.References.Character.SkeletonConfig", "<RootIndex>k__BackingField"),
    ("SkeletonConfig_Legs", "Models.References.Character.SkeletonConfig", "<LegsIndex>k__BackingField"),
    ("SkeletonConfig_Spine2", "Models.References.Character.SkeletonConfig", "<Spine2Index>k__BackingField"),
    ("SkeletonConfig_Spine3", "Models.References.Character.SkeletonConfig", "<Spine3Index>k__BackingField"),
    ("SkeletonConfig_Neck", "Models.References.Character.SkeletonConfig", "<NeckIndex>k__BackingField"),
    ("SkeletonConfig_Head1", "Models.References.Character.SkeletonConfig", "<Head1Index>k__BackingField"),
    ("SkeletonConfig_Head2", "Models.References.Character.SkeletonConfig", "<Head2Index>k__BackingField"),

    # Names / slots
    ("ClientCharacterSlotsModel_SlotByEntityId", "ClientCore.CharacterSlotsModel.ClientCharacterSlotsModel", "_slotByEntityId"),
    ("BattleCharacterSlotModel_Data", "Models.Models.BattleCharacterSlots.BattleCharacterSlotModel", "_data"),
    ("BattleCharacterSlotData_Nickname", "Models.Data.BattleCharacterSlotData", "<Nickname>k__BackingField"),

    # Camera / projection
    ("BattleCameraModel_Position", "Game.Battle.Entities.Player.Camera.BattleCameraModel", "<Position>k__BackingField"),
    ("BattleCameraModel_Orientation", "Game.Battle.Entities.Player.Camera.BattleCameraModel", "<Orientation>k__BackingField"),
    ("BattleCameraModel_Forward", "Game.Battle.Entities.Player.Camera.BattleCameraModel", "<Forward>k__BackingField"),
    ("BattleCameraModel_Right", "Game.Battle.Entities.Player.Camera.BattleCameraModel", "<Right>k__BackingField"),
    ("BattleCameraModel_Up", "Game.Battle.Entities.Player.Camera.BattleCameraModel", "<Up>k__BackingField"),
    ("CinemachineBrain_OutputCamera", "Cinemachine.CinemachineBrain", "m_OutputCamera"),
    ("CinemachineBrain_CameraState", "Cinemachine.CinemachineBrain", "<CurrentCameraState>k__BackingField"),
    ("CameraState_Lens", "Cinemachine.CameraState", "Lens"),
    ("CameraState_RawPosition", "Cinemachine.CameraState", "RawPosition"),
    ("CameraState_RawOrientation", "Cinemachine.CameraState", "RawOrientation"),
    ("CameraState_PositionCorrection", "Cinemachine.CameraState", "PositionCorrection"),
    ("CameraState_OrientationCorrection", "Cinemachine.CameraState", "OrientationCorrection"),
    ("LensSettings_FieldOfView", "Cinemachine.LensSettings", "FieldOfView"),

    # Overlay / wallhack data
    ("OverlayModel_OverlayDict", "Game.Battle.OverlayModel", "_overlayDict"),
    ("CharacterOverlayModel_Position", "Game.Battle.CharacterOverlayModel", "<Position>k__BackingField"),
    ("CharacterOverlayModel_IsVisible", "Game.Battle.CharacterOverlayModel", "<IsVisible>k__BackingField"),
    ("CharacterOverlayModel_IsNicknameVisible", "Game.Battle.CharacterOverlayModel", "<IsNicknameVisible>k__BackingField"),

    # Roles
    ("PlayerRoleDescription_NicknameThroughWall", "Models.References.Battle.PlayerRoleDescription", "<NicknameSameRoleVisibleThroughWall>k__BackingField"),
    ("Identified_Id", "Framework.Core.Identified.Identified", "<Id>k__BackingField"),

    # PlayerRoleDescriptions static field blob (role instance table)
    ("PlayerRoleDescriptions_Settler", "Models.ReferencesProject.Descriptions.Battle.PlayerRoleDescriptions", "<Settler>k__BackingField"),
    ("PlayerRoleDescriptions_Citizen", "Models.ReferencesProject.Descriptions.Battle.PlayerRoleDescriptions", "<Citizen>k__BackingField"),
    ("PlayerRoleDescriptions_Robber", "Models.ReferencesProject.Descriptions.Battle.PlayerRoleDescriptions", "<Robber>k__BackingField"),
    ("PlayerRoleDescriptions_Cop", "Models.ReferencesProject.Descriptions.Battle.PlayerRoleDescriptions", "<Cop>k__BackingField"),
    ("PlayerRoleDescriptions_ClanBattleMember", "Models.ReferencesProject.Descriptions.Battle.PlayerRoleDescriptions", "<ClanBattleMember>k__BackingField"),
    ("PlayerRoleDescriptions_Prisoner", "Models.ReferencesProject.Descriptions.Battle.PlayerRoleDescriptions", "<Prisoner>k__BackingField"),
    ("PlayerRoleDescriptions_Hubber", "Models.ReferencesProject.Descriptions.Battle.PlayerRoleDescriptions", "<Hubber>k__BackingField"),
]

TYPE_SPECS = [
    ("BattleModel", "Game.Battle.BattleModel"),
    ("BattleEntitiesModel", "Game.Battle.BattleEntitiesModel"),
    ("WorldEntitiesModel", "Models.Models.WorldEntities.WorldEntitiesModel"),
    ("BattleCharacterModel", "Models.Models.BattleCharacter.BattleCharacterModel"),
    ("BattleCharacterPrivateModel", "Models.Models.BattleCharacterPrivate.BattleCharacterPrivateModel"),
    ("HealthModel", "Models.Models.Health.HealthModel"),
    ("CharacterTransformModel", "Models.Models.TransformModel.CharacterTransformModel"),
    ("TransformModel", "Models.Models.TransformModel.TransformModel"),
    ("SkeletonModel", "Models.Models.Skeleton.SkeletonModel"),
    ("BattleCharacterSlotModel", "Models.Models.BattleCharacterSlots.BattleCharacterSlotModel"),
    ("BattleCharacterSlotData", "Models.Data.BattleCharacterSlotData"),
    ("ClientCharacterSlotsModel", "ClientCore.CharacterSlotsModel.ClientCharacterSlotsModel"),
    ("BattleCameraModel", "Game.Battle.Entities.Player.Camera.BattleCameraModel"),
    ("CinemachineBrain", "Cinemachine.CinemachineBrain"),
    ("OverlayModel", "Game.Battle.OverlayModel"),
    ("CharacterOverlayModel", "Game.Battle.CharacterOverlayModel"),
    ("PlayerEntityModel", "Game.Battle.EntityModel.Player.PlayerEntityModel"),
    ("PlayerRoleDescription", "Models.References.Battle.PlayerRoleDescription"),
    ("PlayerRoleDescriptions", "Models.ReferencesProject.Descriptions.Battle.PlayerRoleDescriptions"),
    ("IntData", "Framework.Replication.Data.Primitive.IntData"),
]

CLASS_RE = re.compile(
    r'^(?:public|internal|private|protected)?\s*'
    r'(?:sealed\s+|abstract\s+|static\s+|partial\s+)*'
    r'(?:class|struct|interface)\s+([^\s:]+)'
)
FIELD_RE = re.compile(r'^\s+(.+?)\s+([^\s;]+)\s*;\s*//\s*0x([0-9A-Fa-f]+)\s*$')


def parse_dump(path: Path):
    """Returns {full_class_name: {field: offset}} for all non-generic classes."""
    classes: dict[str, dict[str, int]] = {}
    namespace = ""
    current: str | None = None
    with path.open("r", encoding="utf-8-sig", errors="replace") as f:
        for raw in f:
            line = raw.rstrip("\n")
            m = re.match(r'^// Namespace: (.*)$', line)
            if m:
                namespace = m.group(1).strip()
                continue
            if line.startswith("}"):
                current = None
                continue
            m = CLASS_RE.match(line)
            if m and "// TypeDefIndex:" in line:
                name = m.group(1)
                current = f"{namespace}.{name}" if namespace else name
                # Only keep the first declaration of a name.
                classes.setdefault(current, {})
                continue
            if current is not None:
                fm = FIELD_RE.match(line)
                if fm:
                    _, field, off = fm.groups()
                    classes[current].setdefault(field, int(off, 16))
    return classes


def parse_script(path: Path):
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    typeinfo: dict[str, int] = {}
    for entry in data.get("ScriptMetadata", []):
        name = entry.get("Name", "")
        if not name.endswith("_TypeInfo"):
            continue
        typeinfo[name[:-len("_TypeInfo")]] = int(entry["Address"])
    return typeinfo


def main() -> int:
    root = Path(__file__).resolve().parent.parent
    ap = argparse.ArgumentParser()
    ap.add_argument("--dump", type=Path, default=root / "dump.cs")
    ap.add_argument("--script", type=Path, default=root / "script.json")
    ap.add_argument("--out", type=Path, default=root / "src" / "game" / "offsets.h")
    args = ap.parse_args()

    if not args.dump.exists():
        print(f"error: dump.cs not found: {args.dump}", file=sys.stderr)
        return 1
    if not args.script.exists():
        print(f"error: script.json not found: {args.script}", file=sys.stderr)
        return 1

    classes = parse_dump(args.dump)
    typeinfo = parse_script(args.script)

    resolved: list[tuple[str, str, str, int]] = []
    errors: list[str] = []
    for suffix, klass, field in FIELD_SPECS:
        fields = classes.get(klass)
        if fields is None:
            errors.append(f"class not found in dump.cs: {klass}")
            continue
        if field not in fields:
            close = ", ".join(sorted(k for k in fields if field.strip("<>k__BackingField") in k)[:5])
            errors.append(f"field not found: {klass}::{field}" + (f" (candidates: {close})" if close else ""))
            continue
        resolved.append((suffix, klass, field, fields[field]))

    type_resolved: list[tuple[str, str, int]] = []
    for suffix, klass in TYPE_SPECS:
        rva = typeinfo.get(klass)
        if rva is None:
            # Try a suffix match, which handles nested/compat namespace renames.
            candidates = [k for k in typeinfo if k.split(".")[-1] == klass.split(".")[-1]]
            if len(candidates) == 1:
                rva = typeinfo[candidates[0]]
                klass = candidates[0]
            else:
                errors.append(f"TypeInfo not found in script.json: {klass} (candidates: {candidates[:5]})")
                continue
        type_resolved.append((suffix, klass, rva))

    if errors:
        print("Offset generation failed:", file=sys.stderr)
        for e in errors:
            print("  -", e, file=sys.stderr)
        print("\nField names in the dump may have changed after a game update.", file=sys.stderr)
        print("Update FIELD_SPECS/TYPE_SPECS in tools/gen_offsets.py.", file=sys.stderr)
        return 2

    lines: list[str] = []
    lines.append("// AUTO-GENERATED by tools/gen_offsets.py. Do not edit by hand.")
    lines.append("// Source: Il2CppDumper dump.cs + script.json.")
    lines.append("#pragma once")
    lines.append("#include <cstdint>")
    lines.append("")
    lines.append("namespace crown::offsets {")
    width = max(len(s) for s, _, _, _ in resolved)
    for suffix, klass, field, off in resolved:
        lines.append(f"constexpr uint32_t {suffix:<{width}} = 0x{off:X}; // {klass}::{field}")
    lines.append("}")
    lines.append("")
    lines.append("namespace crown::typeinfo {")
    width = max(len(s) for s, _, _ in type_resolved)
    for suffix, klass, rva in type_resolved:
        lines.append(f"constexpr uint64_t {suffix:<{width}} = 0x{rva:X}; // RVA of {klass}_TypeInfo slot")
    lines.append("}")
    lines.append("")

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text("\n".join(lines), encoding="utf-8")
    print(f"wrote {args.out} ({len(resolved)} field offsets, {len(type_resolved)} TypeInfo slots)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())