#define NOMINMAX
#include <windows.h>

#include "render/esp.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <string>

#include "imgui.h"

namespace crown {
namespace {

constexpr float kPi = 3.14159265358979323846f;
constexpr float kDefaultHeight = 1.85f;

struct ScreenPoint {
    float x = 0.0f;
    float y = 0.0f;
};

struct Viewport {
    int x = 0;
    int y = 0;
    int width = 0;
    int height = 0;
};

Viewport GetGameViewport(int overlayWidth, int overlayHeight) {
    Viewport vp{0, 0, overlayWidth, overlayHeight};
    HWND foreground = GetForegroundWindow();
    if (foreground) {
        RECT rect = {};
        if (GetClientRect(foreground, &rect) && rect.right > 0 && rect.bottom > 0) {
            POINT origin = {0, 0};
            ClientToScreen(foreground, &origin);
            vp = {origin.x, origin.y, static_cast<int>(rect.right), static_cast<int>(rect.bottom)};
        }
    }
    return vp;
}

bool WorldToScreen(const Vec3& world, const Vec3& cameraPosition, const Vec3& forward,
                   const Vec3& right, const Vec3& up, float fovDegrees,
                   const Viewport& viewport, ScreenPoint& out) {
    const Vec3 relative = world - cameraPosition;
    const float depth = Dot(relative, forward);
    if (depth <= 0.05f) {
        return false;
    }
    const float tanHalf = std::tan(fovDegrees * kPi / 180.0f * 0.5f);
    const float aspect = static_cast<float>(viewport.width) / static_cast<float>(viewport.height);
    if (tanHalf <= 0.0001f || aspect <= 0.0001f) {
        return false;
    }

    const float x = Dot(relative, right);
    const float y = Dot(relative, up);
    const float ndcX = x / (depth * tanHalf * aspect);
    const float ndcY = y / (depth * tanHalf);

    out.x = static_cast<float>(viewport.x) + (ndcX * 0.5f + 0.5f) * static_cast<float>(viewport.width);
    out.y = static_cast<float>(viewport.y) + (0.5f - ndcY * 0.5f) * static_cast<float>(viewport.height);
    return std::isfinite(out.x) && std::isfinite(out.y);
}

ImU32 ToU32(const ImVec4& color) {
    return ImGui::ColorConvertFloat4ToU32(color);
}

bool RoleVisible(const EspSettings& settings, RoleTeam team) {
    switch (team) {
        case RoleTeam::Robber:
            return settings.roleRobber;
        case RoleTeam::Civil:
            return settings.roleCivil;
        case RoleTeam::Police:
            return settings.rolePolice;
        case RoleTeam::Prisoner:
            return settings.rolePrisoner;
        default:
            return settings.roleUnknown;
    }
}

ImU32 RoleColor(const EspSettings& settings, const PlayerData& player) {
    if (settings.highlightSameRole && player.sameRole) {
        return IM_COL32(90, 230, 120, 255);
    }
    if (!settings.roleColors) {
        return ToU32(settings.boxColor);
    }
    switch (player.roleTeam) {
        case RoleTeam::Police:
            return ToU32(settings.roleColorPolice);
        case RoleTeam::Robber:
            return ToU32(settings.roleColorRobber);
        case RoleTeam::Civil:
            return ToU32(settings.roleColorCivil);
        case RoleTeam::Prisoner:
            return ToU32(settings.roleColorPrisoner);
        default:
            return ToU32(settings.roleColorUnknown);
    }
}

void DrawCornerBox(ImDrawList* draw, float left, float top, float right, float bottom, ImU32 color) {
    const float length = std::clamp((right - left) * 0.30f, 6.0f, 22.0f);
    const float thickness = 1.6f;
    // Top-left
    draw->AddLine(ImVec2(left, top), ImVec2(left + length, top), color, thickness);
    draw->AddLine(ImVec2(left, top), ImVec2(left, top + length), color, thickness);
    // Top-right
    draw->AddLine(ImVec2(right, top), ImVec2(right - length, top), color, thickness);
    draw->AddLine(ImVec2(right, top), ImVec2(right, top + length), color, thickness);
    // Bottom-left
    draw->AddLine(ImVec2(left, bottom), ImVec2(left + length, bottom), color, thickness);
    draw->AddLine(ImVec2(left, bottom), ImVec2(left, bottom - length), color, thickness);
    // Bottom-right
    draw->AddLine(ImVec2(right, bottom), ImVec2(right - length, bottom), color, thickness);
    draw->AddLine(ImVec2(right, bottom), ImVec2(right, bottom - length), color, thickness);
}

}  // namespace

void Esp::TextShadow(ImDrawList* draw, const ImVec2& pos, ImU32 color, const char* text) {
    draw->AddText(ImVec2(pos.x + 1.0f, pos.y + 1.0f), IM_COL32(0, 0, 0, 220), text);
    draw->AddText(pos, color, text);
}

void Esp::Draw(const Snapshot& snapshot, const EspSettings& settings, int overlayWidth, int overlayHeight) {
    ImDrawList* draw = ImGui::GetBackgroundDrawList();
    const Viewport viewport = GetGameViewport(overlayWidth, overlayHeight);
    const float fov = settings.useGameFov && snapshot.fovFromGame ? snapshot.cameraFov : settings.fovOverride;

    if (settings.showStatus) {
        char line[256];
        std::snprintf(line, sizeof(line), "crown dma  |  %s  |  players: %zu", snapshot.status.c_str(),
                      snapshot.players.size());
        TextShadow(draw, ImVec2(12.0f, 10.0f), IM_COL32(230, 230, 230, 255), line);
        std::snprintf(line, sizeof(line), "fov: %.1f%s  |  local: %d  |  roles: %s", fov,
                      snapshot.fovFromGame ? " (game)" : "", snapshot.localId,
                      snapshot.rolesResolved ? "resolved" : "id fallback");
        TextShadow(draw, ImVec2(12.0f, 30.0f), IM_COL32(190, 190, 190, 255), line);
    }

    if (!settings.enabled || !snapshot.inBattle || !snapshot.cameraValid) {
        return;
    }

    const ImVec2 screenCenter(static_cast<float>(viewport.x) + viewport.width * 0.5f,
                              static_cast<float>(viewport.y) + viewport.height * 0.5f);
    const float bottomY = static_cast<float>(viewport.y) + viewport.height;
    int drawn = 0;

    for (const auto& player : snapshot.players) {
        if (drawn >= settings.maxPlayers) {
            break;
        }
        if (!RoleVisible(settings, player.roleTeam)) {
            continue;
        }
        const float distance = Length(player.position - snapshot.localPosition);
        if (distance > settings.maxDistance || distance < 1.0f) {
            continue;
        }

        const float height = player.height > 1.0f ? player.height : kDefaultHeight;
        ScreenPoint feet;
        ScreenPoint head;
        if (!WorldToScreen(player.position, snapshot.cameraPosition, snapshot.cameraForward,
                           snapshot.cameraRight, snapshot.cameraUp, fov, viewport, feet)) {
            continue;
        }
        if (!WorldToScreen(player.position + Vec3{0.0f, height, 0.0f}, snapshot.cameraPosition,
                           snapshot.cameraForward, snapshot.cameraRight, snapshot.cameraUp, fov,
                           viewport, head)) {
            continue;
        }

        const float boxHeight = feet.y - head.y;
        if (boxHeight < 3.0f || boxHeight > 3000.0f) {
            continue;
        }
        const float boxWidth = std::max(6.0f, boxHeight * settings.boxWidthScale);
        const ImU32 color = RoleColor(settings, player);
        const float left = feet.x - boxWidth * 0.5f;
        const float right = feet.x + boxWidth * 0.5f;

        if (settings.snaplines) {
            draw->AddLine(ImVec2(screenCenter.x, bottomY), ImVec2(feet.x, feet.y),
                          IM_COL32(color & 0xFF, (color >> 8) & 0xFF, (color >> 16) & 0xFF, 130), 1.0f);
        }

        if (settings.boxes) {
            if (settings.boxStyle == 1) {
                DrawCornerBox(draw, left, head.y, right, feet.y, color);
            } else {
                draw->AddRect(ImVec2(left - 1.0f, head.y - 1.0f), ImVec2(right + 1.0f, feet.y + 1.0f),
                              IM_COL32(0, 0, 0, 220), 0.0f, 0, 2.0f);
                draw->AddRect(ImVec2(left, head.y), ImVec2(right, feet.y), color, 0.0f, 0, 1.2f);
            }
        }

        if (settings.health) {
            const float ratio = player.maxHealth > 0
                                    ? std::clamp(static_cast<float>(player.health) / player.maxHealth, 0.0f, 1.0f)
                                    : 0.0f;
            const float barX = left - 7.0f;
            draw->AddRectFilled(ImVec2(barX - 1.0f, head.y - 1.0f),
                                ImVec2(barX + 4.0f, feet.y + 1.0f), IM_COL32(0, 0, 0, 190));
            draw->AddRectFilled(ImVec2(barX, feet.y - (feet.y - head.y) * ratio),
                                ImVec2(barX + 3.0f, feet.y),
                                ratio > 0.5f ? IM_COL32(80, 220, 90, 255)
                                             : (ratio > 0.25f ? IM_COL32(240, 200, 60, 255)
                                                              : IM_COL32(235, 70, 70, 255)));
        }

        if (settings.names) {
            const std::string label = player.nameKnown ? player.name : ("entity " + std::to_string(player.id));
            const ImVec2 textSize = ImGui::CalcTextSize(label.c_str());
            TextShadow(draw, ImVec2(feet.x - textSize.x * 0.5f, head.y - textSize.y - 4.0f), color, label.c_str());
        }

        if (settings.distance || settings.roleLabel) {
            char info[160] = {};
            const char* roleText = settings.roleLabel ? player.roleLabel.c_str() : "";
            if (settings.distance && settings.roleLabel) {
                std::snprintf(info, sizeof(info), "%s  %.0fm", roleText, distance);
            } else if (settings.distance) {
                std::snprintf(info, sizeof(info), "%.0fm", distance);
            } else {
                std::snprintf(info, sizeof(info), "%s", roleText);
            }
            if (info[0]) {
                const ImVec2 textSize = ImGui::CalcTextSize(info);
                TextShadow(draw, ImVec2(feet.x - textSize.x * 0.5f, feet.y + 3.0f),
                           IM_COL32(220, 220, 220, 235), info);
            }
        }

        ScreenPoint aim;
        if (WorldToScreen(player.center, snapshot.cameraPosition, snapshot.cameraForward,
                          snapshot.cameraRight, snapshot.cameraUp, fov, viewport, aim)) {
            draw->AddCircle(ImVec2(aim.x, aim.y), 2.0f, color, 8, 1.0f);
        }
        ++drawn;
    }
}

}  // namespace crown
