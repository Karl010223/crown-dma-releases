#pragma once

#include <cstdint>
#include <functional>
#include <string>
#include <vector>

namespace crown {

// Thin wrapper around MemProcFS (vmm.dll).  The DMA device ("-device fpga",
// "-device fpga://...", a physical memory dump, etc.) is passed through to
// MemProcFS untouched.
class Dma {
public:
    Dma() = default;
    ~Dma();

    Dma(const Dma&) = delete;
    Dma& operator=(const Dma&) = delete;

    // argv must include the device arguments, e.g. {"-device", "fpga"}.
    bool Initialize(const std::vector<std::string>& argv);
    void Close();

    bool Attach(const std::string& processName);
    bool GetModuleBase(const std::string& moduleName, uint64_t& base);

    bool Read(uint64_t addr, void* buffer, size_t size) const;
    bool Write(uint64_t addr, const void* buffer, size_t size) const;

    template <typename T>
    bool Read(uint64_t addr, T& value) const {
        return Read(addr, &value, sizeof(T));
    }

    // Reads a NUL-terminated native char string (Il2CppClass::name and friends).
    bool ReadCString(uint64_t addr, std::string& value, size_t maxLen = 128) const;

    // Searches all virtual memory of the attached process for the given 8-byte
    // values.  The callback receives (address, patternIndex); return false to
    // abort the search.
    bool Search(const std::vector<uint64_t>& values,
                const std::function<bool(uint64_t, int)>& callback) const;

    uint32_t pid() const { return pid_; }
    uint64_t moduleBase() const { return moduleBase_; }
    bool valid() const { return handle_ != nullptr && pid_ != 0; }

    // Extended error text from the last failed Initialize() (e.g. "Unable to
    // connect to FPGA device").  Empty on success.
    const std::string& LastError() const { return lastError_; }

private:
    void DiagnoseDevice(const std::string& device);

    void* handle_ = nullptr;
    uint32_t pid_ = 0;
    uint64_t moduleBase_ = 0;
    uint64_t nextDiagnoseAt_ = 0;
    std::string lastError_;
};

}  // namespace crown