#pragma once

#include <atomic>
#include <functional>
#include <cstdint>
#include <mutex>
#include <string>
#include <thread>
#include <unordered_set>
#include <vector>

#include "dma/dma.h"
#include "game/memory.h"

namespace crown {

struct GameOptions {
    std::string processName = "Crown.exe";
    std::string moduleName = "GameAssembly.dll";
    std::vector<std::string> dmaArgs;
};

// Faction the game assigns through PlayerRoleDescription.  "Civil" covers the
// game's Citizen / Settler / Hubber roles.
enum class RoleTeam : uint8_t {
    Unknown = 0,
    Civil,
    Robber,
    Police,
    Prisoner,
    Clan,
};

struct PlayerData {
    int id = 0;
    Vec3 position{};      // feet / character root
    Vec3 center{};        // capsule center (aim point)
    float height = 1.85f;
    int health = 0;
    int maxHealth = 100;
    bool dead = false;
    bool sameRole = false;
    bool nameKnown = false;
    uint64_t roleObject = 0;
    RoleTeam roleTeam = RoleTeam::Unknown;
    std::string name;
    std::string roleId;   // raw PlayerRoleDescription id
    std::string roleLabel;  // display label: POLICE / ROBBER / CIVIL ...
};

struct Snapshot {
    bool attached = false;
    bool inBattle = false;
    bool cameraValid = false;
    bool fovFromGame = false;
    bool rolesResolved = false;
    std::string status = "starting";
    uint64_t battleModel = 0;
    int localId = 0;
    Vec3 localPosition{};
    Vec3 cameraPosition{};
    Vec3 cameraForward{};
    Vec3 cameraRight{};
    Vec3 cameraUp{};
    float cameraFov = 75.0f;
    std::vector<PlayerData> players;
};

class Game {
public:
    Game() = default;
    ~Game();

    Game(const Game&) = delete;
    Game& operator=(const Game&) = delete;

    void Start(const GameOptions& options);
    void Stop();

    Snapshot SnapshotCopy() const;
    void SetWallhack(bool enabled) { wallhack_ = enabled; }
    bool WallhackEnabled() const { return wallhack_; }
    bool Attached() const { return attached_; }

    // Re-runs VMMDLL_Initialize (e.g. after plugging in the FPGA).
    void RequestReconnect() { reconnect_ = true; }

    // Last MemProcFS device error text (empty while connected).
    std::string DmaError() const;

private:
    struct Classes {
        uint64_t battleModel = 0;
        uint64_t battleEntitiesModel = 0;
        uint64_t worldEntitiesModel = 0;
        uint64_t battleCharacterModel = 0;
        uint64_t battleCharacterPrivateModel = 0;
        uint64_t healthModel = 0;
        uint64_t characterTransformModel = 0;
        uint64_t transformModel = 0;
        uint64_t skeletonModel = 0;
        uint64_t battleCharacterSlotModel = 0;
        uint64_t battleCharacterSlotData = 0;
        uint64_t clientCharacterSlotsModel = 0;
        uint64_t battleCameraModel = 0;
        uint64_t cinemachineBrain = 0;
        uint64_t overlayModel = 0;
        uint64_t characterOverlayModel = 0;
        uint64_t playerEntityModel = 0;
        uint64_t playerRoleDescription = 0;
        uint64_t playerRoleDescriptions = 0;
        uint64_t intData = 0;
    };

    // The game builds one PlayerRoleDescription instance per role and keeps
    // them in the static fields of PlayerRoleDescriptions.  Comparing the
    // character's role pointer against these is exact and needs no strings.
    struct RoleSet {
        uint64_t settler = 0;
        uint64_t citizen = 0;
        uint64_t robber = 0;
        uint64_t cop = 0;
        uint64_t clanBattleMember = 0;
        uint64_t prisoner = 0;
        uint64_t hubber = 0;

        bool valid() const { return citizen || robber || cop; }
    };

    void Worker();
    bool Connect();
    bool ResolveClasses();
    bool ResolveClass(uint64_t typeInfoRva, const char* simpleName, uint64_t& out);
    bool ResolveRoleDescriptions();
    bool FindBattleModel();

    bool IsClass(uint64_t object, uint64_t klass) const;
    uint64_t ReadPtr(uint64_t address) const;
    int ReadInt(uint64_t address) const;
    float ReadFloat(uint64_t address) const;
    bool ReadVec3(uint64_t address, Vec3& out) const;
    bool ReadQuat(uint64_t address, Quat& out) const;
    std::string ReadManagedString(uint64_t stringObject) const;

    bool ReadPosition(uint64_t transform, Vec3& out) const;
    bool ReadHealth(uint64_t characterModel, int& amount, int& maxAmount, bool& dead) const;
    std::string ReadRoleId(uint64_t characterModel, uint64_t& roleObject) const;
    void ClassifyRole(PlayerData& player) const;
    std::string ReadNickname(uint64_t slotByEntityId, int entityId) const;

    bool ValidateBattleModel(uint64_t object) const;
    bool ValidateBrain(uint64_t object) const;

    void ApplyWallhack(const Snapshot& snapshot, uint64_t battleEntities, uint64_t battleModel);

    void ForEachDictionaryEntry(uint64_t dictionary,
                                const std::function<void(uint64_t key, uint64_t value)>& callback) const;

    mutable std::mutex mutex_;
    Snapshot snapshot_;
    std::thread worker_;
    std::atomic<bool> running_{false};
    std::atomic<bool> attached_{false};
    std::atomic<bool> wallhack_{false};
    std::atomic<bool> reconnect_{false};

    Dma dma_;
    GameOptions options_;
    Classes classes_;
    RoleSet roles_;
    uint64_t battleModel_ = 0;
    uint64_t brain_ = 0;
    uint64_t worldEntities_ = 0;
    std::unordered_set<uint64_t> patchedRoles_;
    uint64_t nextSearchAt_ = 0;
    uint64_t nextWallhackAt_ = 0;
    uint64_t nextRoleResolveAt_ = 0;
    bool dmaStarted_ = false;
    bool loggedClasses_ = false;
    std::string dmaError_;
    std::string connectStatus_ = "waiting for DMA device";
};

}  // namespace crown