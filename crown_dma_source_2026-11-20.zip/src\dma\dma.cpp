#define NOMINMAX
#include <windows.h>

#include "dma/dma.h"

#include <algorithm>
#include <cstdarg>
#include <cstring>
#include <iostream>
#include <mutex>

#pragma warning(push, 0)
#include "vmmdll.h"
#pragma warning(pop)

namespace crown {
namespace {

struct SearchUser {
    const std::function<bool(uint64_t, int)>* callback;
};

std::mutex g_lcLogMutex;
std::string g_lcLog;

// LeechCore printf callback used by the one-shot device diagnostic.
int LcPrintf(char const* format, ...) {
    char buffer[1024] = {};
    va_list args;
    va_start(args, format);
    const int written = vsnprintf(buffer, sizeof(buffer), format, args);
    va_end(args);
    if (written > 0) {
        std::lock_guard<std::mutex> lock(g_lcLogMutex);
        g_lcLog.append(buffer, std::min<size_t>(static_cast<size_t>(written), sizeof(buffer) - 1));
    }
    return written;
}

std::string WideErrorText(const wchar_t* text, size_t count) {
    if (!text || count == 0) {
        return {};
    }
    const int size = WideCharToMultiByte(CP_UTF8, 0, text, static_cast<int>(count), nullptr, 0, nullptr, nullptr);
    if (size <= 0) {
        return {};
    }
    std::string out(static_cast<size_t>(size), '\0');
    WideCharToMultiByte(CP_UTF8, 0, text, static_cast<int>(count), out.data(), size, nullptr, nullptr);
    // The MemProcFS user text is often padded with newlines.
    while (!out.empty() && (out.back() == '\n' || out.back() == '\r' || out.back() == ' ')) {
        out.pop_back();
    }
    return out;
}

BOOL SearchCallback(PVMMDLL_MEM_SEARCH_CONTEXT ctx, QWORD va, DWORD index) {
    auto* user = static_cast<SearchUser*>(ctx->pvUserPtrOpt);
    if (!user || !user->callback) {
        return FALSE;
    }
    // Returning FALSE aborts the search.  Callbacks are only used to find a
    // handful of validated object pointers, so this is expected when found.
    return (*user->callback)(static_cast<uint64_t>(va), static_cast<int>(index)) ? TRUE : FALSE;
}

}  // namespace

Dma::~Dma() { Close(); }

bool Dma::Initialize(const std::vector<std::string>& argv) {
    Close();

    std::vector<std::string> args;
    args.reserve(argv.size() + 4);
    args.push_back("crown_dma");
    for (const auto& a : argv) {
        args.push_back(a);
    }
    if (args.size() == 1) {
        args.push_back("-device");
        args.push_back("fpga");
    }
    args.push_back("-waitinitialize");

    std::vector<const char*> raw;
    raw.reserve(args.size());
    for (const auto& a : args) {
        raw.push_back(a.c_str());
    }

    PLC_CONFIG_ERRORINFO errorInfo = nullptr;
    handle_ = VMMDLL_InitializeEx(static_cast<DWORD>(raw.size()), raw.data(), &errorInfo);
    if (!handle_) {
        std::string error;
        if (errorInfo) {
            error = WideErrorText(errorInfo->wszUserText, errorInfo->cwszUserText);
            LcMemFree(errorInfo);
        }
        if (error.empty()) {
            error = "no memory acquisition device (check FPGA, USB cable and D3XX driver)";
        }
        if (error != lastError_) {
            std::cerr << "[dma] " << error << "\n";
            lastError_ = error;
        }
        const uint64_t now = GetTickCount64();
        if (now >= nextDiagnoseAt_) {
            nextDiagnoseAt_ = now + 10000;
            std::string device = "fpga";
            for (size_t i = 0; i + 1 < argv.size(); ++i) {
                if (argv[i] == "-device") {
                    device = argv[i + 1];
                }
            }
            DiagnoseDevice(device);
        }
        return false;
    }
    lastError_.clear();
    return true;
}

void Dma::DiagnoseDevice(const std::string& device) {
    {
        std::lock_guard<std::mutex> lock(g_lcLogMutex);
        g_lcLog.clear();
    }

    LC_CONFIG config = {};
    config.dwVersion = LC_CONFIG_VERSION;
    config.dwPrintfVerbosity = LC_CONFIG_PRINTF_ENABLED | LC_CONFIG_PRINTF_V;
    strncpy_s(config.szDevice, sizeof(config.szDevice), device.c_str(), _TRUNCATE);
    config.pfn_printf_opt = &LcPrintf;

    PLC_CONFIG_ERRORINFO errorInfo = nullptr;
    HANDLE lc = LcCreateEx(&config, &errorInfo);
    if (lc) {
        LcClose(lc);
    }
    if (errorInfo) {
        const std::string text = WideErrorText(errorInfo->wszUserText, errorInfo->cwszUserText);
        if (!text.empty()) {
            std::lock_guard<std::mutex> lock(g_lcLogMutex);
            g_lcLog += text;
            g_lcLog += "\n";
        }
        LcMemFree(errorInfo);
    }

    std::lock_guard<std::mutex> lock(g_lcLogMutex);
    if (!g_lcLog.empty()) {
        std::cerr << "[dma] device '" << device << "':\n" << g_lcLog;
    }
}

void Dma::Close() {
    if (handle_) {
        VMMDLL_Close(static_cast<VMM_HANDLE>(handle_));
        handle_ = nullptr;
    }
    pid_ = 0;
    moduleBase_ = 0;
}

bool Dma::Attach(const std::string& processName) {
    if (!handle_) {
        return false;
    }
    DWORD pid = 0;
    if (!VMMDLL_PidGetFromName(static_cast<VMM_HANDLE>(handle_), processName.c_str(), &pid) || pid == 0) {
        return false;
    }
    pid_ = pid;
    return true;
}

bool Dma::GetModuleBase(const std::string& moduleName, uint64_t& base) {
    if (!handle_ || !pid_) {
        return false;
    }
    base = VMMDLL_ProcessGetModuleBaseU(static_cast<VMM_HANDLE>(handle_), pid_, moduleName.c_str());
    if (!base) {
        return false;
    }
    moduleBase_ = base;
    return true;
}

bool Dma::Read(uint64_t addr, void* buffer, size_t size) const {
    if (!handle_ || !pid_ || !addr || !buffer || !size) {
        return false;
    }
    DWORD read = 0;
    if (!VMMDLL_MemReadEx(static_cast<VMM_HANDLE>(handle_), pid_, addr,
                          static_cast<PBYTE>(buffer), static_cast<DWORD>(size), &read, 0)) {
        return false;
    }
    return read == size;
}

bool Dma::Write(uint64_t addr, const void* buffer, size_t size) const {
    if (!handle_ || !pid_ || !addr || !buffer || !size) {
        return false;
    }
    return VMMDLL_MemWrite(static_cast<VMM_HANDLE>(handle_), pid_, addr,
                           const_cast<PBYTE>(static_cast<const BYTE*>(buffer)),
                           static_cast<DWORD>(size)) != FALSE;
}

bool Dma::ReadCString(uint64_t addr, std::string& value, size_t maxLen) const {
    value.clear();
    if (!addr || !maxLen) {
        return false;
    }
    char buffer[256];
    const size_t n = std::min(maxLen, sizeof(buffer));
    if (!Read(addr, buffer, n)) {
        return false;
    }
    buffer[n - 1] = '\0';
    value.assign(buffer);
    return true;
}

bool Dma::Search(const std::vector<uint64_t>& values,
                 const std::function<bool(uint64_t, int)>& callback) const {
    if (!handle_ || !pid_ || values.empty()) {
        return false;
    }

    std::vector<VMMDLL_MEM_SEARCH_CONTEXT_SEARCHENTRY> entries(values.size());
    for (size_t i = 0; i < values.size(); ++i) {
        entries[i] = {};
        entries[i].cbAlign = 8;
        entries[i].cb = 8;
        std::memcpy(entries[i].pb, &values[i], 8);
    }

    SearchUser user{&callback};
    VMMDLL_MEM_SEARCH_CONTEXT ctx = {};
    ctx.dwVersion = VMMDLL_MEM_SEARCH_VERSION;
    ctx.cMaxResult = 0x10000;
    ctx.cSearch = static_cast<DWORD>(entries.size());
    ctx.pSearch = entries.data();
    ctx.vaMin = 0;
    ctx.vaMax = 0;
    ctx.pvUserPtrOpt = &user;
    ctx.pfnResultOptCB = SearchCallback;

    PQWORD hits = nullptr;
    DWORD hitCount = 0;
    const BOOL ok = VMMDLL_MemSearch(static_cast<VMM_HANDLE>(handle_), pid_, &ctx, &hits, &hitCount);
    if (hits) {
        VMMDLL_MemFree(hits);
    }
    // A callback abort is reported as a failed search by MemProcFS; the found
    // flag is owned by the caller.
    (void)ok;
    return true;
}

}  // namespace crown